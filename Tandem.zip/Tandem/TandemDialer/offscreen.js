// offscreen.js — Captures tab audio and streams to Deepgram
let dgSocket = null;
let audioCtx = null;
let processor = null;

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'offscreen-start' && msg.streamId) {
    startCapture(msg.streamId);
    sendResponse({ ok: true });
  }
  if (msg.type === 'offscreen-stop') {
    stopCapture();
    sendResponse({ ok: true });
  }
  return true;
});

async function startCapture(streamId) {
  try {
    // Get the tab audio stream using the stream ID from tabCapture
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        mandatory: {
          chromeMediaSource: 'tab',
          chromeMediaSourceId: streamId
        }
      }
    });

    console.log('[Tandem Offscreen] Got tab audio stream');

    // Set up audio processing at 16kHz for Deepgram
    audioCtx = new AudioContext({ sampleRate: 16000 });
    const source = audioCtx.createMediaStreamSource(stream);
    processor = audioCtx.createScriptProcessor(4096, 1, 1);
    source.connect(processor);
    processor.connect(audioCtx.destination);

    // Connect to Deepgram
    const key = TANDEM_CONFIG?.DEEPGRAM_API_KEY;
    if (!key || key.includes('YOUR_')) {
      chrome.runtime.sendMessage({ type: 'rb-system', text: '⚠️ Set DEEPGRAM_API_KEY in config.js' });
      return;
    }

    const url = 'wss://api.deepgram.com/v1/listen?' + new URLSearchParams({
      model: 'nova-2',
      language: 'en-US',
      smart_format: 'true',
      interim_results: 'true',
      utterance_end_ms: '1500',
      encoding: 'linear16',
      sample_rate: '16000',
      channels: '1'
    });

    dgSocket = new WebSocket(url, ['token', key]);

    dgSocket.onopen = () => {
      console.log('[Tandem Offscreen] Deepgram connected');
      chrome.runtime.sendMessage({ type: 'rb-system', text: '🎧 Listening to call...' });
      chrome.runtime.sendMessage({ type: 'rb-listening', active: true });
    };

    dgSocket.onmessage = (e) => {
      try {
        const data = JSON.parse(e.data);
        if (data.type === 'UtteranceEnd') {
          chrome.runtime.sendMessage({ type: 'rb-utterance-end' });
          return;
        }
        if (data.type !== 'Results') return;
        const text = data.channel?.alternatives?.[0]?.transcript?.trim();
        if (!text) return;
        chrome.runtime.sendMessage({
          type: 'rb-transcript',
          text: text,
          isFinal: data.is_final
        });
      } catch (err) {}
    };

    dgSocket.onerror = () => {
      chrome.runtime.sendMessage({ type: 'rb-system', text: '⚠️ Transcription error' });
    };

    dgSocket.onclose = () => {
      chrome.runtime.sendMessage({ type: 'rb-listening', active: false });
    };

    // Stream audio chunks to Deepgram
    processor.onaudioprocess = (e) => {
      if (!dgSocket || dgSocket.readyState !== WebSocket.OPEN) return;
      const float32 = e.inputBuffer.getChannelData(0);

      // Skip silence
      let sum = 0;
      for (let i = 0; i < float32.length; i++) sum += Math.abs(float32[i]);
      if (sum / float32.length < 0.001) return;

      // Convert Float32 → Int16 PCM
      const int16 = new Int16Array(float32.length);
      for (let i = 0; i < float32.length; i++) {
        const s = Math.max(-1, Math.min(1, float32[i]));
        int16[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
      }
      dgSocket.send(int16.buffer);
    };

    // Handle stream ending (call hangup)
    stream.getAudioTracks()[0].addEventListener('ended', () => {
      console.log('[Tandem Offscreen] Audio track ended');
      stopCapture();
      chrome.runtime.sendMessage({ type: 'rb-system', text: '📞 Call ended' });
      chrome.runtime.sendMessage({ type: 'rb-listening', active: false });
    });

  } catch (err) {
    console.error('[Tandem Offscreen] Capture error:', err);
    chrome.runtime.sendMessage({ type: 'rb-system', text: '⚠️ Could not capture audio: ' + err.message });
  }
}

function stopCapture() {
  if (processor) { processor.disconnect(); processor = null; }
  if (audioCtx) { audioCtx.close().catch(() => {}); audioCtx = null; }
  if (dgSocket) {
    try { dgSocket.send(JSON.stringify({ type: 'CloseStream' })); } catch (e) {}
    dgSocket.close();
    dgSocket = null;
  }
}
