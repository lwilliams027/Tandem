// ═══════════════════════════════════════════════════════
// vm-detect.js — No-answer detection via remote audio analysis
// Runs in MAIN world inside the Plivo dialer iframe
// Alongside iframe-hook.js (which captures the PCM)
//
// Detects two conditions after call is answered:
//   1. SILENCE: No real speech for ~5s from answer (1s grace + 4s silence)
//   2. BEEP: Sustained single-frequency tone (400-2000Hz) for >300ms
//
// Either condition → posts tandem-vm-detected → answer-override.js
// reclassifies the "answered" call as "no answer" and moves on.
//
// IMPORTANT: Audio energy alone does NOT cancel detection.
// A voicemail greeting plays audio too. Only a confirmed Deepgram
// CLIENT transcript (tandem-speech-confirmed) cancels detection.
// ═══════════════════════════════════════════════════════

(function() {
  'use strict';

  // ─── Config ───
  var SILENCE_THRESHOLD = 150;     // Int16 RMS below this = silence (out of 32768)
  var SILENCE_GRACE_MS = 1000;     // 1s grace for call audio to stabilise
  var SILENCE_REQUIRED_MS = 4000;  // 4s continuous silence after grace ≈ 5s total
  var MONITOR_WINDOW_MS = 10000;   // Stop monitoring after 10s (real person by then)
  var BEEP_MIN_DURATION_MS = 300;  // Beep must last at least 300ms
  var BEEP_FREQ_MIN = 400;         // Hz — lower bound for beep detection
  var BEEP_FREQ_MAX = 2000;        // Hz — upper bound for beep detection
  var BEEP_DOMINANCE = 0.60;       // Peak frequency must be >60% of total energy
  var SAMPLE_RATE = 16000;         // PCM sample rate from iframe-hook.js

  // ─── State ───
  var monitoring = false;
  var answerTime = 0;
  var silenceStartTime = 0;
  var beepStartTime = 0;
  var beepFreq = 0;
  var detected = false;
  var speechConfirmed = false;       // Deepgram said the CLIENT spoke

  // ─── Goertzel algorithm for efficient single-frequency detection ───
  function goertzel(samples, targetFreq, sampleRate) {
    var numSamples = samples.length;
    var k = Math.round(numSamples * targetFreq / sampleRate);
    var w = 2 * Math.PI * k / numSamples;
    var cosw = Math.cos(w);
    var coeff = 2 * cosw;
    var s0 = 0, s1 = 0, s2 = 0;

    for (var i = 0; i < numSamples; i++) {
      s0 = samples[i] + coeff * s1 - s2;
      s2 = s1;
      s1 = s0;
    }

    return Math.sqrt(s1 * s1 + s2 * s2 - coeff * s1 * s2);
  }

  // ─── Analyze a PCM chunk for beep ───
  function detectBeep(int16Array) {
    var samples = new Float32Array(int16Array.length);
    for (var i = 0; i < int16Array.length; i++) {
      samples[i] = int16Array[i] / 32768.0;
    }

    var totalEnergy = 0;
    for (var i = 0; i < samples.length; i++) {
      totalEnergy += samples[i] * samples[i];
    }
    if (totalEnergy < 0.001) return { isBeep: false, freq: 0 };

    var testFreqs = [440, 480, 620, 800, 850, 1000, 1200, 1400, 1600, 1800];
    var maxPower = 0;
    var maxFreq = 0;

    for (var f = 0; f < testFreqs.length; f++) {
      var power = goertzel(samples, testFreqs[f], SAMPLE_RATE);
      if (power > maxPower) {
        maxPower = power;
        maxFreq = testFreqs[f];
      }
    }

    for (var freq = BEEP_FREQ_MIN; freq <= BEEP_FREQ_MAX; freq += 50) {
      var power = goertzel(samples, freq, SAMPLE_RATE);
      if (power > maxPower) {
        maxPower = power;
        maxFreq = freq;
      }
    }

    var totalMag = Math.sqrt(totalEnergy * samples.length);
    var dominance = totalMag > 0 ? (maxPower / totalMag) : 0;

    return {
      isBeep: dominance > BEEP_DOMINANCE && maxFreq >= BEEP_FREQ_MIN && maxFreq <= BEEP_FREQ_MAX,
      freq: maxFreq,
      dominance: dominance
    };
  }

  // ─── Calculate RMS of Int16 PCM ───
  function calcRMS(int16Array) {
    var sum = 0;
    for (var i = 0; i < int16Array.length; i++) {
      sum += int16Array[i] * int16Array[i];
    }
    return Math.sqrt(sum / int16Array.length);
  }

  // ─── Process incoming PCM chunk ───
  function processChunk(buffer) {
    if (!monitoring || detected) return;

    var now = Date.now();
    var elapsed = now - answerTime;

    // Stop monitoring after window expires
    if (elapsed > MONITOR_WINDOW_MS) {
      stopMonitoring('timeout');
      return;
    }

    var samples = new Int16Array(buffer);
    var rms = calcRMS(samples);

    // ── Check for beep (any time during monitoring) ──
    var beepResult = detectBeep(samples);
    if (beepResult.isBeep) {
      if (beepStartTime === 0) {
        beepStartTime = now;
        beepFreq = beepResult.freq;
      } else if (now - beepStartTime >= BEEP_MIN_DURATION_MS) {
        detected = true;
        console.log('[VM Detect] BEEP at ' + beepFreq + 'Hz (' +
                    (now - beepStartTime) + 'ms, dom=' + beepResult.dominance.toFixed(2) + ')');
        emitDetection('beep');
        return;
      }
    } else {
      if (beepStartTime > 0) {
        beepStartTime = 0;
        beepFreq = 0;
      }
    }

    // ── Check for silence (after grace period) ──
    if (elapsed < SILENCE_GRACE_MS) return;

    if (rms > SILENCE_THRESHOLD) {
      // Audio energy detected — but this does NOT cancel detection.
      // A voicemail greeting has audio too. Only Deepgram confirmation
      // of CLIENT speech (tandem-speech-confirmed) cancels.
      // Reset silence timer since there IS sound playing.
      silenceStartTime = 0;
    } else {
      // Silence
      if (silenceStartTime === 0) {
        silenceStartTime = now;
      } else if (!speechConfirmed && now - silenceStartTime >= SILENCE_REQUIRED_MS) {
        detected = true;
        var totalSec = Math.round((now - answerTime) / 1000);
        console.log('[VM Detect] SILENCE (' + (now - silenceStartTime) +
                    'ms continuous, ' + totalSec + 's from answer)');
        emitDetection('silence');
        return;
      }
    }
  }

  // ─── Emit detection result ───
  function emitDetection(reason) {
    monitoring = false;
    window.postMessage({
      type: 'tandem-vm-detected',
      reason: reason,
      elapsed: Date.now() - answerTime
    }, '*');
    console.log('[VM Detect] Posted tandem-vm-detected: ' + reason);
  }

  // ─── Start monitoring ───
  function startMonitoring() {
    if (monitoring) return;
    monitoring = true;
    detected = false;
    speechConfirmed = false;
    answerTime = Date.now();
    silenceStartTime = 0;
    beepStartTime = 0;
    beepFreq = 0;
    console.log('[VM Detect] Monitoring started (grace=' + SILENCE_GRACE_MS +
                'ms, silence=' + SILENCE_REQUIRED_MS + 'ms, window=' + MONITOR_WINDOW_MS + 'ms)');
  }

  // ─── Stop monitoring ───
  function stopMonitoring(reason) {
    if (!monitoring) return;
    monitoring = false;
    console.log('[VM Detect] Monitoring stopped: ' + (reason || 'manual'));
  }

  // ─── Cancel (speech confirmed by Deepgram) ───
  function cancelDetection() {
    if (!monitoring || detected) return;
    speechConfirmed = true;
    silenceStartTime = 0;
    console.log('[VM Detect] Detection cancelled — confirmed client speech');
  }

  // ─── Listen for events ───
  window.addEventListener('message', function(e) {
    if (!e.data || !e.data.type) return;

    // Remote audio PCM — analyze it
    if (e.data.type === 'tandem-pcm' && monitoring && !detected) {
      processChunk(e.data.buffer);
    }

    // Call answered — start monitoring
    if (e.data.type === 'ail-answered') {
      startMonitoring();
    }

    // Call terminated — stop monitoring
    if (e.data.type === 'ail-terminated' || e.data.type === 'ail-failed') {
      stopMonitoring('call_ended');
    }

    // Deepgram CLIENT transcript = real person, cancel detection
    if (e.data.type === 'tandem-speech-confirmed') {
      cancelDetection();
    }
  });

  // Backup trigger on capture-started
  window.addEventListener('message', function(e) {
    if (e.data && e.data.type === 'tandem-capture-started' && !monitoring && !detected) {
      setTimeout(function() {
        if (!monitoring && !detected) {
          startMonitoring();
        }
      }, 2000);
    }
  });

  console.log('[VM Detect] Loaded — waiting for call answer');
})();
