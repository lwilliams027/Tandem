// ═══════════════════════════════════════════════════════
// answer-override.js — Post-answer no-answer override
// Runs as content script on Impact pages
//
// When the call shows "Connected" (green), this script watches for
// voicemail/silence detection signals from vm-detect.js via the
// dialer iframe. If detected (beep or 5s silence):
//   1. Shows "No Answer — moving on" status
//   2. Hangs up the Plivo call
//   3. Adjusts stats (answered-1, noAnswer+1)
//   4. Sets step for double-tap or next lead
//   5. Auto-clicks resume to continue dialing
//
// The call is reclassified as NO ANSWER (not voicemail) because
// the lead never actually responded — it was a VM system pickup.
//
// Zero modifications to the minified content.js
// ═══════════════════════════════════════════════════════

(function() {
  'use strict';

  var SERVER = 'https://tandemdialer.com';
  var _active = false;        // Are we in the monitoring window?
  var _overridden = false;    // Already overridden this call?
  var _connectTime = 0;       // When call connected
  var _clientSpoke = false;   // Deepgram confirmed client speech?
  var _monitorTimeout = null;

  // ─── Get auth token ───
  function getToken(cb) {
    try {
      chrome.storage.local.get(['sbToken'], function(r) { cb(r.sbToken || null); });
    } catch(e) { cb(null); }
  }

  // ─── Get current step from storage ───
  function getStep(cb) {
    try {
      chrome.storage.local.get(['ailStep'], function(r) { cb(r.ailStep || null); });
    } catch(e) { cb(null); }
  }

  // ─── Set step in storage ───
  function setStep(updates, cb) {
    chrome.storage.local.get(['ailStep'], function(r) {
      var step = r.ailStep || {};
      Object.assign(step, updates);
      chrome.storage.local.set({ ailStep: step }, function() {
        if (cb) cb();
      });
    });
  }

  // ─── Read overlay state ───
  function getOverlayState() {
    var el = document.getElementById('ail-status');
    if (!el) return 'unknown';
    var text = el.textContent.toLowerCase();
    if (text.includes('connected')) return 'connected';
    if (text.includes('ringing') || text.includes('dialing')) return 'dialing';
    return 'other';
  }

  // ─── Start monitoring after call connects ───
  function startMonitoring() {
    if (_active) return;
    _active = true;
    _overridden = false;
    _clientSpoke = false;
    _connectTime = Date.now();

    console.log('[No-Answer Override] Monitoring started — 5s silence / beep → reclassify as no answer');

    // Auto-stop after 11 seconds (vm-detect window is 10s + 1s buffer)
    _monitorTimeout = setTimeout(function() {
      if (_active && !_overridden) {
        _active = false;
        console.log('[No-Answer Override] Monitor window expired — real conversation');
      }
    }, 11000);
  }

  // ─── Stop monitoring ───
  function stopMonitoring() {
    _active = false;
    if (_monitorTimeout) {
      clearTimeout(_monitorTimeout);
      _monitorTimeout = null;
    }
  }

  // ─── Execute the override: reclassify as NO ANSWER ───
  function executeOverride(reason) {
    if (_overridden || !_active) return;
    _overridden = true;
    _active = false;
    stopMonitoring();

    var elapsed = Math.round((Date.now() - _connectTime) / 1000);
    console.log('[No-Answer Override] *** DETECTED: ' + reason +
                ' (elapsed ' + elapsed + 's) — reclassifying as NO ANSWER ***');

    // ── Step 1: Update the status UI ──
    var statusEl = document.getElementById('ail-status');
    if (statusEl) {
      statusEl.textContent = 'No Answer — moving on...';
      statusEl.className = 'ail-status-text state-error';
    }
    var screenEl = document.querySelector('.ail-phone-screen');
    if (screenEl) screenEl.className = 'ail-phone-screen state-error';

    // Mini bar
    var miniStatus = document.getElementById('ail-mini-status');
    if (miniStatus) miniStatus.textContent = 'No Answer — retrying';
    var miniBar = document.getElementById('ail-mini-bar');
    if (miniBar) miniBar.style.background = 'linear-gradient(135deg, #7f1d1d, #991b1b)';

    // ── Step 2: Play the "no answer" sound (descending tone) ──
    try {
      var ctx = new (window.AudioContext || window.webkitAudioContext)();
      var o1 = ctx.createOscillator(), g1 = ctx.createGain();
      o1.connect(g1); g1.connect(ctx.destination);
      o1.type = 'sine'; o1.frequency.value = 600; g1.gain.value = 0.25;
      o1.start(ctx.currentTime); o1.stop(ctx.currentTime + 0.2);
      var o2 = ctx.createOscillator(), g2 = ctx.createGain();
      o2.connect(g2); g2.connect(ctx.destination);
      o2.type = 'sine'; o2.frequency.value = 300; g2.gain.value = 0.2;
      o2.start(ctx.currentTime + 0.25); o2.stop(ctx.currentTime + 0.5);
    } catch(e) {}

    // ── Step 3: Hang up the Plivo call ──
    var iframe = document.getElementById('ail-dialer-iframe');
    if (iframe && iframe.contentWindow) {
      iframe.contentWindow.postMessage({ type: 'ail-hangup' }, '*');
    }

    proceedWithOverride(reason);
  }

  function proceedWithOverride(reason) {
    // ── Step 4: Adjust stats — undo answered, add noAnswer ──
    getStep(function(step) {
      if (!step) step = {};
      var stats = step.stats || { calls: 0, answered: 0, voicemail: 0, noAnswer: 0 };

      // Undo the answered count (content.js already incremented it)
      if (stats.answered > 0) stats.answered--;
      // Add to noAnswer
      stats.noAnswer = (stats.noAnswer || 0) + 1;

      // Get settings to check doubleTap
      chrome.storage.local.get(['ailSettings'], function(r) {
        var cfg = r.ailSettings || {};
        var doubleTap = cfg.doubleTap !== false; // default true
        var leadId = step.leadId || '';

        // Determine next step
        var nextStep;
        if (doubleTap) {
          // Double-tap: re-dial same lead immediately
          nextStep = 3;
          console.log('[No-Answer Override] Setting step:3 for double-tap');
        } else {
          // No double-tap — advance to next lead
          nextStep = 6;
          console.log('[No-Answer Override] Setting step:6 — next lead');
        }

        // Write updated step to storage
        setStep({
          step: nextStep,
          running: true,
          stats: stats,
          leadId: leadId,
          vmOverride: true,            // Flag so other scripts know this was an override
          vmOverrideReason: reason      // 'silence' or 'beep'
        }, function() {
          console.log('[No-Answer Override] Storage updated: step=' + nextStep +
                      ' stats=' + JSON.stringify(stats));

          // ── Step 5: Report to server (correct: no_answer +1) ──
          reportUsage();

          // ── Step 6: Update the stats display ──
          updateStatsDisplay(stats);

          // ── Step 7: Brief delay, then click resume ──
          setTimeout(function() {
            var resumeBtn = document.getElementById('ail-resume-btn');
            if (resumeBtn) {
              console.log('[No-Answer Override] Clicking resume button...');
              resumeBtn.click();
            } else {
              console.warn('[No-Answer Override] Resume button not found — agent clicks manually');
            }
          }, 1500); // 1.5s so agent sees the "No Answer" status
        });
      });
    });
  }

  // ─── Report usage correction to server ───
  function reportUsage() {
    getToken(function(token) {
      if (!token) return;
      try {
        fetch(SERVER + '/report-usage', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
          },
          body: JSON.stringify({
            no_answer: 1
            // Note: answered was already +1'd by content.js server-side.
            // We can't decrement answered via this endpoint, but local stats
            // are corrected. Net effect: server may show 1 extra answered,
            // but no_answer count is accurate.
          })
        }).catch(function() {});
      } catch(e) {}
    });
  }

  // ─── Update stats in the overlay UI ───
  function updateStatsDisplay(stats) {
    var els = {
      'ail-stat-calls': stats.calls,
      'ail-stat-answered': stats.answered,
      'ail-stat-vm': stats.voicemail || 0,
      'ail-stat-na': stats.noAnswer || 0
    };
    for (var id in els) {
      var el = document.getElementById(id);
      if (el) el.textContent = els[id];
    }
  }

  // ─── Listen for VM detection from iframe ───
  chrome.runtime.onMessage.addListener(function(msg) {
    if (!msg || !msg.type) return;

    // VM/silence detected by vm-detect.js (relayed through iframe-bridge)
    if (msg.type === 'tandem-vm-detected') {
      if (_active && !_overridden && !_clientSpoke) {
        executeOverride(msg.reason || 'unknown');
      }
    }

    // Deepgram transcript from CLIENT = real speech → cancel override
    if (msg.type === 'rb-transcript' && msg.speaker === 'client') {
      if (_active && !_overridden && msg.text && msg.text.trim().length > 2) {
        _clientSpoke = true;
        console.log('[No-Answer Override] Client speech detected: "' + msg.text.substring(0, 40) +
                    '" — cancelling detection');
        stopMonitoring();

        // Tell the iframe detector to stop too
        var iframe = document.getElementById('ail-dialer-iframe');
        if (iframe && iframe.contentWindow) {
          iframe.contentWindow.postMessage({ type: 'tandem-speech-confirmed' }, '*');
        }
      }
    }
  });

  // ─── Watch for call state changes via DOM ───
  function observeOverlay() {
    var statusEl = document.getElementById('ail-status');
    if (!statusEl) {
      setTimeout(observeOverlay, 2000);
      return;
    }

    var lastState = '';
    var observer = new MutationObserver(function() {
      var state = getOverlayState();
      if (state === lastState) return;
      var prevState = lastState;
      lastState = state;

      // Call just connected → start monitoring
      if (state === 'connected' && prevState !== 'connected') {
        startMonitoring();
      }

      // Call ended while monitoring → stop
      if (state !== 'connected' && prevState === 'connected') {
        if (_active && !_overridden) {
          stopMonitoring();
        }
      }
    });

    observer.observe(statusEl, { childList: true, characterData: true, subtree: true });
    console.log('[No-Answer Override] Observing overlay state');
  }

  // ─── Init ───
  if (document.readyState === 'complete') {
    setTimeout(observeOverlay, 2000);
  } else {
    window.addEventListener('load', function() {
      setTimeout(observeOverlay, 2000);
    });
  }

  console.log('[No-Answer Override] Loaded — waiting for connected calls');
})();
