/**
 * Tandem AI Coach — v2.5 Full Compliance
 *
 * RULE 2 INTEGRATION: When prospect says "take me off / stop calling / remove me":
 *   - Shows red DNC card (NOT a rebuttal)
 *   - Sends number to server DNC list immediately
 *   - No rebuttal suggestion for DNC requests
 *
 * + Two-party consent state blocking (v2.4)
 * + Dual speaker transcription + learning (v2.3)
 * + Interim scan speed + expanded patterns (v2.3.1)
 */
(function(){
  'use strict';

  var TWO_PARTY_CODES = new Set([203,206,209,213,215,217,223,224,239,240,253,267,272,279,301,302,305,309,310,312,321,323,331,339,341,350,351,352,360,369,386,406,407,408,410,412,413,415,424,425,442,443,445,447,464,475,484,508,509,510,530,559,561,562,564,570,582,603,610,617,618,619,626,628,630,650,657,661,667,669,702,707,708,714,717,724,725,727,747,754,760,764,772,773,774,775,779,781,786,805,813,814,815,818,820,831,835,840,847,850,857,858,860,863,872,878,904,909,916,925,941,949,951,954,959,978]);
  var TWO_PARTY_STATES = {203:'CT',206:'WA',209:'CA',213:'CA',215:'PA',217:'IL',223:'PA',224:'IL',239:'FL',240:'MD',253:'WA',267:'PA',272:'PA',279:'CA',301:'MD',302:'DE',305:'FL',309:'IL',310:'CA',312:'IL',321:'FL',323:'CA',331:'IL',339:'MA',341:'CA',350:'CA',351:'MA',352:'FL',360:'WA',369:'CA',386:'FL',406:'MT',407:'FL',408:'CA',410:'MD',412:'PA',413:'MA',415:'CA',424:'CA',425:'WA',442:'CA',443:'MD',445:'PA',447:'IL',464:'IL',475:'CT',484:'PA',508:'MA',509:'WA',510:'CA',530:'CA',559:'CA',561:'FL',562:'CA',564:'WA',570:'PA',582:'PA',603:'NH',610:'PA',617:'MA',618:'IL',619:'CA',626:'CA',628:'CA',630:'IL',650:'CA',657:'CA',661:'CA',667:'MD',669:'CA',702:'NV',707:'CA',708:'IL',714:'CA',717:'PA',724:'PA',725:'NV',727:'FL',747:'CA',754:'FL',760:'CA',764:'CA',772:'FL',773:'IL',774:'MA',775:'NV',779:'IL',781:'MA',786:'FL',805:'CA',813:'FL',814:'PA',815:'IL',818:'CA',820:'CA',831:'CA',835:'PA',840:'CA',847:'IL',850:'FL',857:'MA',858:'CA',860:'CT',863:'FL',872:'IL',878:'PA',904:'FL',909:'CA',916:'CA',925:'CA',941:'FL',949:'CA',951:'CA',954:'FL',959:'CT',978:'MA'};

  function isTwoPartyState(phone) { if (!phone) return false; var d = phone.replace(/\D/g,''); if (d.length===11&&d[0]==='1') d=d.substring(1); if (d.length<10) return false; return TWO_PARTY_CODES.has(parseInt(d.substring(0,3),10)); }
  function getTwoPartyState(phone) { if (!phone) return ''; var d = phone.replace(/\D/g,''); if (d.length===11&&d[0]==='1') d=d.substring(1); if (d.length<10) return ''; return TWO_PARTY_STATES[parseInt(d.substring(0,3),10)]||''; }

  var COOLDOWN = 1200, DEBOUNCE_INT = 80, DEBOUNCE_FIN = 120, BUFFER_MAX_AGE = 25000, AI_TIMEOUT = 3000;
  var wordBuffer = [], lastRbTime = 0, pendingAI = false;
  var firedTags = {}, panelOpen = false;
  var _callId = null, _strengthPref = 'medium', _savedRebuttals = [], _cardCounter = 0, _localCache = {};
  var _lineIdx = {}, history = [];
  var _lastInterimScan = '', _transcriptFadeTimer = null;
  var _convo = [], _objections = [], _callStartTime = 0;
  var _blocked = false, _blockedState = '';
  var _currentLeadPhone = '';

  try { chrome.storage.local.get(['savedRebuttals','strengthPref'], function(r) { if (r.savedRebuttals) _savedRebuttals=r.savedRebuttals; if (r.strengthPref) _strengthPref=r.strengthPref; }); } catch(e) {}

  /* ═══ DNC PATTERN — handled separately, never shows rebuttal ═══ */
  var DNC_PATTERN = /take me off|remove me|do not call|stop calling|don'?t call (me )?(again|back|anymore)|lose my number|put me on.*(do not|don'?t).*call/i;

  /* ═══ OBJECTIONS ═══ */
  var OBJECTIONS = [
    { re: /can'?t afford|too expensive|no money|tight right now|budget is tight|don'?t have the money|money is tight/i, tag: 'cost', label: 'Too Expensive', icon: '\uD83D\uDCB0', conf: 0.92 },
    { re: /already have insurance|already covered|have a policy|got coverage|have benefits|i'?m covered/i, tag: 'has_insurance', label: 'Has Insurance', icon: '\uD83D\uDEE1\uFE0F', conf: 0.92 },
    { re: /not interested|no thanks?|don'?t want|no thank you|don'?t need|i'?m good|we'?re good|all set|i'?ll pass|no way|absolutely not|hard pass|nah i'?m good/i, tag: 'not_interested', label: 'Not Interested', icon: '\uD83D\uDE45', conf: 0.88 },
    { re: /talk to (my )?(wife|husband|spouse|partner)|let me ask (my )?(wife|husband|spouse)|my (wife|husband) handles|check with (my )?(wife|husband|spouse)/i, tag: 'spouse', label: 'Talk to Spouse', icon: '\uD83D\uDC65', conf: 0.93 },
    { re: /send (me )?(something|info|mail|email|brochure)|mail it|put it in the mail|just email|email me|send (it |that )?to my email/i, tag: 'send_info', label: 'Send Info', icon: '\uD83D\uDCE7', conf: 0.90 },
    { re: /too busy|bad time|call (me )?back|busy right now|in a meeting|don'?t have time|no time|not a good time|i'?m (at )?work|i'?m driving|in the middle of|right now is not|can you (call|try) (me )?(back|later|another|tomorrow)|call another time|try me later/i, tag: 'busy', label: 'Busy / Call Back', icon: '\u23F0', conf: 0.90 },
    { re: /think about it|need to think|sleep on it|decide later|pray on it|let me think|give me (some )?time|need (some )?time|mull it over/i, tag: 'stall', label: 'Need to Think', icon: '\u23F3', conf: 0.88 },
    { re: /scam|fraud|legit|real company|who are you|never heard|how did you get my (number|info)|where (are )?you calling from|what company|what organization|sounds? (too good|fishy|sketchy|shady)|is this real|are you real/i, tag: 'trust', label: 'Distrust', icon: '\uD83D\uDD12', conf: 0.88 },
    { re: /no money|broke|paycheck|can'?t pay|between (pay)?checks|funds are low|strapped/i, tag: 'no_money', label: 'No Money', icon: '\uD83D\uDCB8', conf: 0.90 },
    { re: /work (covers?|insurance|benefits)|through (my )?job|employer (covers?|provides?)|job (covers?|provides?)|company (covers?|provides?)|covered (at|through|by) work/i, tag: 'work_coverage', label: 'Work Coverage', icon: '\uD83C\uDFED', conf: 0.88 },
    { re: /already did|already (met|seen|done)|done this before|had this|been through this|already (went|looked|been)|we already|did this last/i, tag: 'already_done', label: 'Already Done', icon: '\uD83D\uDCCB', conf: 0.86 },
    { re: /have an agent|my agent|my guy|my person|my insurance (guy|gal|person|agent|lady)|already have someone/i, tag: 'has_agent', label: 'Has an Agent', icon: '\uD83D\uDC64', conf: 0.86 },
    { re: /sell|buy|purchase|selling|pitch|are you (going to|trying to)|is this a sales|what are you selling|sales call|telemarket/i, tag: 'selling', label: 'Afraid of Sales', icon: '\uD83D\uDED2', conf: 0.78 },
    { re: /why (do I |should I )?meet|why (do I )?need to|what is this (about|for|regarding)?|what'?s this about|purpose of/i, tag: 'why_meet', label: 'Why Meet?', icon: '\u2753', conf: 0.78 },
    { re: /why zoom|come (to|in)|in person|over the phone|virtual|can'?t you (just )?tell me (now|on the phone)|do this (over the|on the) phone/i, tag: 'why_zoom', label: 'Why Zoom?', icon: '\uD83D\uDCBB', conf: 0.75 },
    { re: /just looking|just browsing|exploring|checking|exploring my options|shopping around/i, tag: 'browsing', label: 'Just Looking', icon: '\uD83D\uDC40', conf: 0.70 },
    { re: /how much|is there a (cost|charge|fee)|what'?s (the|it) (cost|catch)|what does it cost|is it free|what'?s the catch|any (cost|charge|fee)/i, tag: 'cost', label: 'Cost Question', icon: '\uD83D\uDCB0', conf: 0.72 },
    { re: /cost|price/i, tag: 'cost', label: 'Too Expensive', icon: '\uD83D\uDCB0', conf: 0.62 },
    { re: /already have/i, tag: 'has_insurance', label: 'Has Insurance', icon: '\uD83D\uDEE1\uFE0F', conf: 0.65 },
    { re: /spouse/i, tag: 'spouse', label: 'Talk to Spouse', icon: '\uD83D\uDC65', conf: 0.65 },
    { re: /trust/i, tag: 'trust', label: 'Distrust', icon: '\uD83D\uDD12', conf: 0.60 },
  ];

  /* ═══ BANK ═══ */
  var BANK = {
    'cost':[{r:"I hear you. The good news is this is a no-cost benefit \u2014 it's already pre-paid through your union.",f:"Does 6 or 7:30 tomorrow work better?",tone:'warm'},{r:"I completely understand. This doesn't cost you anything \u2014 it's included in your membership.",f:"Are you usually home by 6?",tone:'soft'}],
    'has_insurance':[{r:"That's great you're covered. This is separate \u2014 union-approved benefits that work alongside what you have.",f:"Does 6 or 7:30 work for a quick Zoom?",tone:'confident'},{r:"Perfect. These are supplemental benefits through your union \u2014 they fill in the gaps.",f:"When are you and your spouse usually home?",tone:'warm'}],
    'not_interested':[{r:"I hear you. The company still requires me to explain your new benefits. It'll be quick.",f:"Does 6 or 7:30 tomorrow work better?",tone:'direct'},{r:"No problem. I'm not here to sell \u2014 just to review what's included.",f:"Can we do a quick 20-minute Zoom tomorrow?",tone:'soft'},{r:"I totally respect that. This was already approved through your union \u2014 I'm just the messenger.",f:"Quick 20 minutes, does tomorrow work?",tone:'warm'}],
    'spouse':[{r:"Great question \u2014 they're the one who'd actually use the benefit. Important they understand.",f:"When are you both usually home from work?",tone:'warm'},{r:"Absolutely. We need both of you there because it covers your whole family.",f:"What time works for both of you tomorrow?",tone:'confident'}],
    'send_info':[{r:"The union already mailed the card \u2014 my job is just to make sure everything is processed.",f:"Quick Zoom is all it takes \u2014 does 6 or 7:30 work?",tone:'direct'},{r:"These benefits are personalized to your family though, so a brochure can't capture it. Only takes 20 minutes.",f:"Are you free tomorrow evening?",tone:'soft'}],
    'busy':[{r:"I get it. That's why they made this so quick \u2014 just 20 minutes.",f:"Does 6 or 7:30 tomorrow work better?",tone:'direct'},{r:"No problem. I don't need to talk now. Just need to find a time.",f:"When will you be free tomorrow evening?",tone:'warm'},{r:"Totally understand, I won't keep you. Let me just grab a time.",f:"Does tomorrow at 6 or 7:30 work?",tone:'soft'}],
    'stall':[{r:"Of course. Spots are filling up quick. I only have a few left this week.",f:"Can I lock you in for tomorrow at 6 or 7:30?",tone:'confident'},{r:"Absolutely. I want to make sure you're taken care of too.",f:"What time works tomorrow?",tone:'warm'}],
    'trust':[{r:"Great question. American Income has been serving unions for over 70 years \u2014 100% union company.",f:"Would a quick 20-minute Zoom put your mind at ease?",tone:'confident'},{r:"Your union specifically partners with us. I'm just here to review what's included.",f:"Does tomorrow evening work?",tone:'warm'},{r:"Your union gave us your info because you qualify. We're the only company they work with.",f:"Quick Zoom \u2014 does 6 or 7:30 work?",tone:'direct'}],
    'selling':[{r:"I'm not here to sell. My job is just to review the updates so you know what's included.",f:"Quick 20 minutes \u2014 does 6 or 7:30 work?",tone:'soft'}],
    'why_meet':[{r:"Union-approved benefits. My job is just to explain how they work. Quick and easy.",f:"Does 6 or 7:30 tomorrow work?",tone:'confident'}],
    'why_zoom':[{r:"We do everything over Zoom now \u2014 just clicking a link, takes about 20 minutes.",f:"Have you used Zoom before?",tone:'soft'},{r:"There's some documents I need to share on screen. It's quick \u2014 20 minutes.",f:"Does tomorrow evening work?",tone:'warm'}],
    'already_done':[{r:"Your benefits are up for renewal at no cost. Just need to re-list your beneficiaries.",f:"Quick Zoom \u2014 does 6 or 7:30 work?",tone:'confident'}],
    'work_coverage':[{r:"This is separate \u2014 it's supplemental, goes with you even if you change jobs.",f:"Does 6 or 7:30 work for a quick review?",tone:'confident'}],
    'has_agent':[{r:"I'm not here to replace anyone. These are additional union-specific benefits.",f:"Quick 20 minutes \u2014 does tomorrow work?",tone:'soft'}],
    'browsing':[{r:"Perfect. I'll walk you through what's available and you decide.",f:"Does 6 or 7:30 tomorrow work?",tone:'warm'}],
    'no_money':[{r:"These benefits are pre-paid through your union \u2014 no cost to you for the review.",f:"Can I get you set up for a quick Zoom tomorrow?",tone:'warm'}],
  };

  /* ═══ TRANSCRIPT LISTENER ═══ */
  var _scanTimerInt = null, _scanTimerFin = null;
  chrome.runtime.onMessage.addListener(function(msg) {
    if (msg.type !== 'rb-transcript' || !msg.text) return;
    if (_blocked) return;
    var text = msg.text.trim(); if (!text) return;
    var speaker = msg.speaker || 'client';
    if (msg.isFinal) _convo.push({ speaker: speaker, text: text, ts: Date.now() });
    if (speaker === 'client') {
      if (msg.isFinal) {
        var now = Date.now();
        text.split(/\s+/).forEach(function(w) { wordBuffer.push({ w: w, t: now }); });
        while (wordBuffer.length > 0 && now - wordBuffer[0].t > BUFFER_MAX_AGE) wordBuffer.shift();
        showTranscript(text, true, 'client');
        if (_scanTimerFin) clearTimeout(_scanTimerFin);
        _scanTimerFin = setTimeout(function() { _scanTimerFin = null; scanFinal(); }, DEBOUNCE_FIN);
      } else {
        showTranscript(text, false, 'client');
        if (text !== _lastInterimScan && text.length >= 5) {
          _lastInterimScan = text;
          if (_scanTimerInt) clearTimeout(_scanTimerInt);
          _scanTimerInt = setTimeout(function() { _scanTimerInt = null; scanInterim(text); }, DEBOUNCE_INT);
        }
      }
    } else {
      if (msg.isFinal) showTranscript(text, true, 'agent');
      else showTranscript(text, false, 'agent');
    }
  });

  function showTranscript(text, isFinal, speaker) {
    var el = document.getElementById('acp-transcript'); if (!el) return;
    var prefix = speaker === 'agent' ? '\uD83D\uDDE3\uFE0F ' : '\uD83C\uDFA4 ';
    el.textContent = prefix + text;
    el.className = 'acp-transcript' + (speaker === 'agent' ? ' acp-tx-agent' : ' acp-tx-client') + (isFinal ? ' acp-tx-final' : ' acp-tx-interim');
    if (_transcriptFadeTimer) clearTimeout(_transcriptFadeTimer);
    _transcriptFadeTimer = setTimeout(function() { el.classList.add('acp-tx-fade'); }, isFinal ? 4000 : 8000);
  }

  /* ═══ SCAN — DNC check runs FIRST, before objections ═══ */
  function scanInterim(text) {
    if (_blocked) return;
    // ── DNC CHECK FIRST ──
    if (!firedTags['_dnc'] && DNC_PATTERN.test(text)) {
      firedTags['_dnc'] = true;
      lastRbTime = Date.now();
      triggerDNC(text);
      return;
    }
    if (Date.now() - lastRbTime < COOLDOWN) return;
    for (var j = 0; j < OBJECTIONS.length; j++) {
      if (OBJECTIONS[j].re.test(text)) {
        var obj = OBJECTIONS[j]; if (firedTags[obj.tag]) continue; if (obj.conf < 0.50) continue;
        firedTags[obj.tag] = true; lastRbTime = Date.now();
        _objections.push({ type: obj.tag, clientText: text, ts: Date.now() });
        fireBankCard(text, obj); return;
      }
    }
  }

  function scanFinal() {
    if (_blocked) return;
    var now = Date.now(), recent = [];
    for (var i = wordBuffer.length - 1; i >= 0; i--) { if (now - wordBuffer[i].t > 8000) break; recent.unshift(wordBuffer[i].w); }
    var text = recent.join(' '); if (text.length < 8) return;
    // ── DNC CHECK FIRST ──
    if (!firedTags['_dnc'] && DNC_PATTERN.test(text)) {
      firedTags['_dnc'] = true; lastRbTime = Date.now();
      triggerDNC(text); return;
    }
    for (var j = 0; j < OBJECTIONS.length; j++) {
      if (OBJECTIONS[j].re.test(text)) {
        var obj = OBJECTIONS[j];
        if (firedTags[obj.tag] && firedTags[obj.tag] !== 'ai_done' && !_localCache[obj.tag]) {
          firedTags[obj.tag] = 'ai_done'; fireAIUpgrade(text, obj); return;
        }
        if (!firedTags[obj.tag] && obj.conf >= 0.50 && Date.now() - lastRbTime >= COOLDOWN) {
          firedTags[obj.tag] = true; lastRbTime = Date.now();
          _objections.push({ type: obj.tag, clientText: text, ts: Date.now() });
          fireBankCard(text, obj); firedTags[obj.tag] = 'ai_done'; fireAIUpgrade(text, obj); return;
        }
      }
    }
    if (recent.length >= 10 && !pendingAI && Date.now() - lastRbTime >= COOLDOWN) { lastRbTime = Date.now(); fireAIOnly(text); }
  }

  /* ═══ DNC TRIGGER — red card + server add ═══ */
  function triggerDNC(text) {
    var phone = _currentLeadPhone || getLeadPhone();
    // Show red DNC card
    showDNCCard(phone, text);
    // Send to server
    if (phone) {
      try {
        chrome.runtime.sendMessage({ type: 'addToDNC', payload: {
          phone_number: phone,
          reason: 'verbal_request',
          agent_name: '',
          lead_name: '',
          call_id: _callId || ''
        }});
      } catch(e) {}
    }
    _objections.push({ type: 'dnc_request', clientText: text, ts: Date.now() });
    updateStatus('blocked', 'DNC');
  }

  function showDNCCard(phone, text) {
    var cards = document.getElementById('acp-cards'); if (!cards) return;
    var empty = cards.querySelector('.acp-empty'); if (empty) empty.remove();
    var c = document.createElement('div');
    c.className = 'acp-card acp-card-new acp-card-dnc';
    c.innerHTML = '<div class="acp-card-head" style="background:rgba(220,38,38,0.15)">' +
      '<span class="acp-card-icon">\uD83D\uDEAB</span>' +
      '<span class="acp-card-label" style="color:#f87171">DNC REQUEST</span>' +
      '</div>' +
      '<div class="acp-card-rebuttal" style="color:#fca5a5;font-size:11px">' +
        'Number added to Do Not Call list.<br>' +
        '<span style="color:rgba(255,255,255,0.4);font-size:10px">' + esc(phone || '?') + '</span>' +
      '</div>' +
      '<div class="acp-card-followup" style="color:#f87171;font-size:10px">' +
        '\u2192 End the call politely. This number will be blocked from future dials.' +
      '</div>';
    cards.insertBefore(c, cards.firstChild);
    requestAnimationFrame(function() { c.classList.add('acp-card-in'); });
    // Alert chime
    try { var x = new (window.AudioContext || window.webkitAudioContext)(), o1 = x.createOscillator(), g1 = x.createGain(); o1.connect(g1); g1.connect(x.destination); o1.type = 'sine'; o1.frequency.value = 400; g1.gain.value = 0.08; o1.start(); o1.stop(x.currentTime + 0.15); var o2 = x.createOscillator(), g2 = x.createGain(); o2.connect(g2); g2.connect(x.destination); o2.type = 'sine'; o2.frequency.value = 300; g2.gain.value = 0.06; o2.start(x.currentTime + 0.2); o2.stop(x.currentTime + 0.4); } catch(e) {}
  }

  function fireBankCard(text, obj) {
    var bank = BANK[obj.tag]; if (!bank || !bank.length) return;
    var cached = _localCache[obj.tag];
    var idx = (_lineIdx[obj.tag] || 0) % bank.length; _lineIdx[obj.tag] = idx + 1; var line = bank[idx];
    var cardId = addCard({ label: obj.label, icon: obj.icon, rebuttal: cached ? (cached.rebuttal || line.r) : line.r,
      followUp: cached ? (cached.follow_up || line.f) : line.f, tone: line.tone, isAI: !!cached, confidence: obj.conf,
      sourceDoc: cached ? cached.source_doc : null, alternate: cached ? cached.alternate : null, tag: obj.tag });
    firedTags[obj.tag] = cardId || true;
    updateStatus('detected', obj.label);
    setTimeout(function() { if (_lastState === 'connected') updateStatus('listening'); }, 3000);
  }

  function fireAIUpgrade(text, obj) {
    if (_blocked || pendingAI || _localCache[obj.tag]) return;
    var cardId = (typeof firedTags[obj.tag] === 'string' && firedTags[obj.tag].indexOf('acp-card-') === 0) ? firedTags[obj.tag] : null;
    pendingAI = true;
    callRAG(text, obj.tag, obj.conf, null, function(resp) { pendingAI = false; if (resp) { var rb = normalizeResponse(resp); _localCache[obj.tag] = rb; if (cardId) upgradeCard(cardId, resp); } });
  }

  function fireAIOnly(text) {
    if (_blocked) return;
    pendingAI = true; updateStatus('thinking');
    callRAG(text, null, 0.50, null, function(resp) { pendingAI = false;
      if (resp) { var rb = normalizeResponse(resp); if (rb.type) _localCache[rb.type] = rb;
        addCard({ label: rb.type || 'Rebuttal', icon: '\u26A1', rebuttal: rb.rebuttal, followUp: rb.follow_up, tone: 'ai', isAI: true, confidence: rb.confidence || 0.50, sourceDoc: rb.source_doc || null, alternate: rb.alternate || null, tag: rb.type || '' });
        updateStatus('detected', rb.type || 'Rebuttal'); }
      setTimeout(function() { if (_lastState === 'connected') updateStatus('listening'); }, 3000); });
  }

  /* ═══ CALL STATE ═══ */
  var _lastState = '';
  setInterval(function() {
    try { if (!chrome.runtime.id) return; } catch(e) { return; }
    var el = document.getElementById('ail-status'); if (!el) return;
    var cls = el.className || '';
    var state = (cls.indexOf('state-connected') >= 0) ? 'connected' : 'idle';
    if (state === _lastState) return;
    var prev = _lastState; _lastState = state;
    if (state === 'connected') {
      wordBuffer = []; firedTags = {}; _localCache = {}; _lastInterimScan = '';
      _convo = []; _objections = [];
      _callId = 'call_' + Date.now(); _callStartTime = Date.now(); history = [];
      _currentLeadPhone = getLeadPhone();
      if (isTwoPartyState(_currentLeadPhone)) {
        _blocked = true; _blockedState = getTwoPartyState(_currentLeadPhone);
        try { chrome.runtime.sendMessage({ type: 'rb-block-transcription' }); } catch(e) {}
        if (!panelOpen) showPanel();
        showBlockedState(_blockedState); return;
      }
      _blocked = false; _blockedState = '';
      try { chrome.runtime.sendMessage({ type: 'rb-unblock-transcription' }); } catch(e) {}
      if (!panelOpen) showPanel(); updateStatus('listening'); clearCards();
    }
    if (prev === 'connected' && state !== 'connected') {
      if (!_blocked && _convo.length > 0 && _callId) {
        var dur = Math.round((Date.now() - _callStartTime) / 1000);
        sendCallTranscript(_callId, _convo, _objections, dur);
      }
      _blocked = false; _blockedState = '';
      try { chrome.runtime.sendMessage({ type: 'rb-unblock-transcription' }); } catch(e) {}
      wordBuffer = []; firedTags = {}; _localCache = {}; _lastInterimScan = '';
      _convo = []; _objections = []; _callId = null; _currentLeadPhone = ''; updateStatus('idle');
    }
  }, 300);

  function getLeadPhone() { var el = document.querySelector('.ail-lead-phone'); if (el && el.textContent) return el.textContent.trim(); var tel = document.querySelectorAll('a[href^="tel:"]'); if (tel.length > 0) return tel[0].href.replace('tel:','').trim(); return ''; }
  function showBlockedState(sc) { var c = document.getElementById('acp-cards'); if (c) c.innerHTML = '<div class="acp-blocked"><div class="acp-blocked-icon">\uD83D\uDD12</div><div class="acp-blocked-title">Coach Paused</div><div class="acp-blocked-reason">' + sc + ' requires all-party consent.<br>No audio is being processed.</div></div>'; var t = document.getElementById('acp-transcript'); if (t) { t.textContent = ''; t.style.display = 'none'; } updateStatus('blocked', sc); }
  function sendCallTranscript(cid, convo, obj, dur) { if (_blocked) return; try { chrome.runtime.sendMessage({ type: 'saveCallTranscript', payload: { call_id: cid, duration: dur, transcript: convo.map(function(c) { return { s: c.speaker==='agent'?'a':'c', t: c.text, ts: c.ts }; }), objections: obj.map(function(o) { return { type: o.type, text: o.clientText, ts: o.ts }; }), objection_count: obj.length }}); } catch(e) {} }

  /* ═══ RAG API ═══ */
  function callRAG(text, tag, conf, intent, cb) { if (_blocked) { cb(null); return; } var payload = { prospect_text: text, objection_type: tag||null, confidence: conf||0.50, intent: intent||null, strength_pref: _strengthPref, call_id: _callId, model: 'gpt-4o-mini', messages: buildLegacy(text, tag), max_tokens: 150, temperature: 0.7 }; var aborted = false, tid = setTimeout(function() { aborted = true; cb(null); }, AI_TIMEOUT); chrome.runtime.sendMessage({ type: 'rebuttalQuery', payload: payload }, function(resp) { clearTimeout(tid); if (aborted) return; try { if (!resp || !resp.ok) { cb(null); return; } if (resp.rag) { cb(resp.rag); return; } if (resp.data && resp.data.choices) { var raw = resp.data.choices[0].message.content.trim(); history.push({ role: 'assistant', content: raw }); if (raw.indexOf('[listening]') >= 0) { cb(null); return; } try { var j = JSON.parse(raw); if (j.rebuttal) cb(j); else cb(null); } catch(e) { cb({ rebuttal: raw.replace(/\n.*$/s, '').substring(0, 150), follow_up: '', type: tag || '' }); } } else cb(null); } catch(e) { cb(null); } }); }
  function buildLegacy(text, tag) { var SYS = 'You are an AI rebuttal coach for AIL appointment setters on LIVE calls.\nCONTEXT: Agent calls union members to SET A ZOOM APPOINTMENT.\nFRAMEWORK: 1.ACKNOWLEDGE 2.REFRAME 3.MICRO-CLOSE\nRULES: Under 30 words. JSON: {"rebuttal":"...","follow_up":"...","type":"..."}'; var m = tag ? 'Objection: ' + tag + ' | "' + text + '"' : '"' + text + '"'; history.push({ role: 'user', content: m }); return [{ role: 'system', content: SYS }].concat(history.slice(-4)); }
  function normalizeResponse(r) { if (r.primary_rebuttal) return { rebuttal: r.primary_rebuttal, follow_up: r.follow_up||'', type: r.objection_type||'', confidence: r.confidence||0, tone: r.tone||'', source_doc: r.source_doc||null, alternate: r.alternate_rebuttal||null }; if (r.r) return { rebuttal: r.r, follow_up: r.f||'', type: r.t||'' }; return { rebuttal: r.rebuttal||'', follow_up: r.follow_up||'', type: r.type||'', source_doc: r.source_doc||null, alternate: r.alternate||null }; }

  /* ═══ PANEL ═══ */
  function showPanel() { if (document.getElementById('ail-coach-panel')) { panelOpen = true; return; } var p = document.createElement('div'); p.id = 'ail-coach-panel'; p.innerHTML = '<div class="acp-header"><div class="acp-dot" id="acp-dot"></div><span class="acp-title">AI Coach</span><span class="acp-status" id="acp-status">Standby</span><span class="acp-strength" id="acp-strength" title="Rebuttal strength"><span class="acp-str-dot' + (_strengthPref === 'light' ? ' acp-str-active' : '') + '" data-str="light"></span><span class="acp-str-dot' + (_strengthPref === 'medium' ? ' acp-str-active' : '') + '" data-str="medium"></span><span class="acp-str-dot' + (_strengthPref === 'strong' ? ' acp-str-active' : '') + '" data-str="strong"></span></span><span class="acp-close" id="acp-close">\u2212</span></div><div class="acp-transcript" id="acp-transcript"></div><div class="acp-cards" id="acp-cards"><div class="acp-empty">Listening for objections\u2026</div></div>'; document.body.appendChild(p); panelOpen = true; p.querySelector('#acp-strength').addEventListener('click', function(e) { var d = e.target.closest('.acp-str-dot'); if (!d) return; _strengthPref = d.getAttribute('data-str'); p.querySelectorAll('.acp-str-dot').forEach(function(x) { x.classList.remove('acp-str-active'); }); d.classList.add('acp-str-active'); try { chrome.storage.local.set({ strengthPref: _strengthPref }); } catch(e) {} }); var hdr = p.querySelector('.acp-header'), drag = false, dx = 0, dy = 0; hdr.addEventListener('mousedown', function(e) { if (e.target.id === 'acp-close' || e.target.closest('#acp-strength')) return; drag = true; dx = e.clientX - p.offsetLeft; dy = e.clientY - p.offsetTop; p.style.transition = 'none'; }); document.addEventListener('mousemove', function(e) { if (!drag) return; p.style.left = Math.max(0, e.clientX - dx) + 'px'; p.style.top = Math.max(0, e.clientY - dy) + 'px'; p.style.right = 'auto'; }); document.addEventListener('mouseup', function() { if (drag) { drag = false; p.style.transition = 'all 0.2s'; } }); document.getElementById('acp-close').onclick = function() { var c = p.querySelector('.acp-cards'), t = p.querySelector('.acp-transcript'); var m = p.classList.toggle('acp-minimized'); if (c) c.style.display = m ? 'none' : ''; if (t) t.style.display = m ? 'none' : ''; this.textContent = m ? '+' : '\u2212'; }; }

  /* ═══ ADD CARD ═══ */
  function addCard(o) { if (_blocked) return null; var cards = document.getElementById('acp-cards'); if (!cards) return null; var empty = cards.querySelector('.acp-empty'); if (empty) empty.remove(); var id = 'acp-card-' + (++_cardCounter), conf = o.confidence || 0; var cc = conf >= 0.8 ? 'acp-conf-high' : (conf >= 0.5 ? 'acp-conf-med' : 'acp-conf-low'); var c = document.createElement('div'); c.className = 'acp-card acp-card-new'; c.id = id; c.setAttribute('data-tag', o.tag || ''); c.innerHTML = '<div class="acp-card-head"><span class="acp-card-icon">' + o.icon + '</span><span class="acp-card-label">' + esc(o.label) + '</span><span class="acp-conf-dot ' + cc + '" title="' + Math.round(conf * 100) + '%"></span>' + (o.isAI ? '<span class="acp-ai-tag">\u2728 AI</span>' : '') + '<span class="acp-card-actions"><span class="acp-btn-regen" title="Regenerate">\u21BB</span><span class="acp-btn-pin" title="Save">\u2606</span><span class="acp-card-x" title="Dismiss">\u2715</span></span></div><div class="acp-card-rebuttal" data-role="rebuttal">' + esc(o.rebuttal) + '</div>' + (o.followUp ? '<div class="acp-card-followup" data-role="followup">\u2192 ' + esc(o.followUp) + '</div>' : '') + (o.alternate ? '<div class="acp-card-alt" data-role="alt" style="display:none"><span class="acp-alt-label">Alt:</span> ' + esc(o.alternate) + '</div>' : '') + '<div class="acp-card-footer">' + (o.alternate ? '<span class="acp-alt-toggle">Alt</span>' : '') + '<span class="acp-card-tone">' + esc(o.tone || '') + '</span>' + (o.sourceDoc ? '<span class="acp-card-source">via ' + esc(o.sourceDoc) + '</span>' : '') + '</div>'; cards.insertBefore(c, cards.firstChild); var all = cards.querySelectorAll('.acp-card'); for (var i = 4; i < all.length; i++) all[i].remove(); requestAnimationFrame(function() { c.classList.add('acp-card-in'); }); c.querySelector('.acp-card-x').onclick = function() { c.classList.add('acp-card-out'); setTimeout(function() { c.remove(); lastRbTime = 0; }, 250); }; c.querySelector('.acp-btn-regen').onclick = function() { var tag = c.getAttribute('data-tag'), txt = getRecentText(); if (!txt) return; updateStatus('thinking'); callRAG(txt, tag, 0.80, null, function(r) { if (r) { var rb = normalizeResponse(r); if (tag) _localCache[tag] = rb; var re = c.querySelector('[data-role="rebuttal"]'); if (re) { re.style.opacity = '0.4'; setTimeout(function() { re.textContent = rb.rebuttal; re.style.opacity = '1'; }, 150); } var fe = c.querySelector('[data-role="followup"]'); if (fe && rb.follow_up) fe.textContent = '\u2192 ' + rb.follow_up; if (!c.querySelector('.acp-ai-tag')) { var b = document.createElement('span'); b.className = 'acp-ai-tag'; b.textContent = '\u2728 AI'; var a = c.querySelector('.acp-card-actions'); if (a) a.before(b); } } setTimeout(function() { if (_lastState === 'connected') updateStatus('listening'); }, 2000); }); }; c.querySelector('.acp-btn-pin').onclick = function() { var re = c.querySelector('[data-role="rebuttal"]'); if (!re) return; _savedRebuttals.unshift({ tag: c.getAttribute('data-tag'), label: o.label, rebuttal: re.textContent, savedAt: Date.now() }); if (_savedRebuttals.length > 50) _savedRebuttals = _savedRebuttals.slice(0, 50); try { chrome.storage.local.set({ savedRebuttals: _savedRebuttals }); } catch(e) {} this.textContent = '\u2605'; this.classList.add('acp-pinned'); }; c.querySelector('[data-role="rebuttal"]').onclick = function() { try { navigator.clipboard.writeText(this.textContent).then(function() { c.classList.add('acp-copied'); setTimeout(function() { c.classList.remove('acp-copied'); }, 600); }); } catch(e) {} }; var at = c.querySelector('.acp-alt-toggle'); if (at) at.onclick = function() { var a = c.querySelector('[data-role="alt"]'); if (a) a.style.display = a.style.display === 'none' ? '' : 'none'; }; try { var x = new (window.AudioContext || window.webkitAudioContext)(), os = x.createOscillator(), g = x.createGain(); os.connect(g); g.connect(x.destination); os.type = 'sine'; os.frequency.value = 800; g.gain.value = 0.04; os.start(); os.stop(x.currentTime + 0.08); } catch(e) {} return id; }
  function upgradeCard(id, resp) { if (_blocked) return; var c = document.getElementById(id); if (!c) return; var rb = normalizeResponse(resp); if (!rb.rebuttal || rb.rebuttal === '[listening]') return; var re = c.querySelector('[data-role="rebuttal"]'); if (re && rb.rebuttal) { re.style.opacity = '0.4'; setTimeout(function() { re.textContent = rb.rebuttal; re.style.opacity = '1'; }, 150); } var fe = c.querySelector('[data-role="followup"]'); if (fe && rb.follow_up) fe.textContent = '\u2192 ' + rb.follow_up; if (!c.querySelector('.acp-ai-tag')) { var h = c.querySelector('.acp-card-head'); if (h) { var b = document.createElement('span'); b.className = 'acp-ai-tag'; b.textContent = '\u2728 AI'; var a = h.querySelector('.acp-card-actions'); if (a) h.insertBefore(b, a); } } }

  function getRecentText() { var now = Date.now(), r = []; for (var i = wordBuffer.length - 1; i >= 0; i--) { if (now - wordBuffer[i].t > 12000) break; r.unshift(wordBuffer[i].w); } return r.join(' '); }
  function clearCards() { var c = document.getElementById('acp-cards'); if (c) c.innerHTML = '<div class="acp-empty">Listening for objections\u2026</div>'; var t = document.getElementById('acp-transcript'); if (t) { t.textContent = ''; t.className = 'acp-transcript'; t.style.display = ''; } }
  function updateStatus(s, x) { var d = document.getElementById('acp-dot'), st = document.getElementById('acp-status'); if (d) { d.className = 'acp-dot'; if (s==='listening') d.classList.add('acp-dot-on'); else if (s==='detected') d.classList.add('acp-dot-flash'); else if (s==='thinking') d.classList.add('acp-dot-pulse'); else if (s==='blocked') d.classList.add('acp-dot-err'); else if (s==='error') d.classList.add('acp-dot-err'); } if (st) { if (s==='idle') st.textContent='Standby'; else if (s==='listening') st.textContent='Listening\u2026'; else if (s==='detected') st.textContent='\u26A1 '+(x||'Detected'); else if (s==='thinking') st.textContent='AI analyzing\u2026'; else if (s==='blocked') st.textContent='\uD83D\uDD12 '+(x||'')+' \u2014 Paused'; else if (s==='error') st.textContent='Offline'; } }
  function esc(s) { var d = document.createElement('div'); d.textContent = s; return d.innerHTML; }
})();
