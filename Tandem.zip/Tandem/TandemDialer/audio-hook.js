// audio-hook.js — Injected into MAIN world to capture prospect's voice
(function(){
  const Orig = window.RTCPeerConnection || window.webkitRTCPeerConnection;
  if (!Orig) return;
  let ctx = null, proc = null, on = false;

  window.RTCPeerConnection = function(...a) {
    const pc = new Orig(...a);
    pc.addEventListener('track', e => {
      if (e.track.kind === 'audio' && !on) {
        on = true;
        console.log('[Tandem] Remote audio captured');
        start(new MediaStream([e.track]));
        e.track.addEventListener('ended', () => { stop(); });
      }
    });
    return pc;
  };
  window.RTCPeerConnection.prototype = Orig.prototype;
  Object.keys(Orig).forEach(k => { window.RTCPeerConnection[k] = Orig[k]; });
  if (window.webkitRTCPeerConnection) window.webkitRTCPeerConnection = window.RTCPeerConnection;

  function start(stream) {
    try {
      ctx = new AudioContext({ sampleRate: 16000 });
      const src = ctx.createMediaStreamSource(stream);
      proc = ctx.createScriptProcessor(4096, 1, 1);
      src.connect(proc);
      proc.connect(ctx.destination);
      proc.onaudioprocess = e => {
        const f = e.inputBuffer.getChannelData(0);
        let sum = 0;
        for (let i = 0; i < f.length; i++) sum += Math.abs(f[i]);
        if (sum / f.length < 0.001) return;
        const b = new Int16Array(f.length);
        for (let i = 0; i < f.length; i++) {
          const s = Math.max(-1, Math.min(1, f[i]));
          b[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
        }
        window.postMessage({ type: 'tandem-audio', buffer: b.buffer }, '*', [b.buffer]);
      };
      window.postMessage({ type: 'tandem-audio-on' }, '*');
    } catch(e) { console.error('[Tandem] Audio err:', e); }
  }
  function stop() {
    on = false;
    if (proc) { proc.disconnect(); proc = null; }
    if (ctx) { ctx.close().catch(()=>{}); ctx = null; }
    window.postMessage({ type: 'tandem-audio-off' }, '*');
  }
  window.addEventListener('message', e => {
    if (e.data?.type === 'tandem-stop-audio') stop();
  });
})();
