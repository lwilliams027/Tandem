// ═══════════════════════════════════════════════════════
// youtube-player.js — YouTube music player for overlay
// Minimal bar + search/recents drawer
// No API keys, no OAuth, no user limits
// ═══════════════════════════════════════════════════════

const YouTubePlayer = (function() {
  'use strict';

  const PRESETS = [
    { name: 'Lofi Chill',    listId: 'PLOzDu-MXXLliO9fBNZOQTBDddoA3FzZUo', icon: '\u2615' },
    { name: 'Focus Beats',   listId: 'PLrAXtmErZgOeiKm4sgNOknGvNjby9efdf', icon: '\uD83C\uDFB5' },
    { name: 'Late Night',    listId: 'PLgzTt0k8mXzEk586SfGBUBMFRmo6lMGvI', icon: '\uD83C\uDF19' },
    { name: 'Hip Hop',       listId: 'PLDcnymzs18LU4Kexrs91TVdfnplU3I5zs', icon: '\uD83D\uDD25' },
    { name: 'Rock',          listId: 'PLhd1HyMTk3f5SL62vPEajrQ9D6kJIEsEJ', icon: '\uD83C\uDFB8' },
  ];

  var _container = null, _iframe = null, _playing = false, _currentPreset = -1;
  var _wasPaused = false, _volume = 50, _expanded = false, _videoTitle = '', _ready = false;
  var _recents = [];
  var MAX_RECENTS = 5;

  function injectStyles() {
    if (document.getElementById('yt-player-css')) return;
    var s = document.createElement('style'); s.id = 'yt-player-css';
    s.textContent = [
      '.yt-bar{display:flex;align-items:center;gap:6px;padding:6px 10px;background:rgba(15,10,42,0.5);border-radius:10px;margin:6px 0;cursor:pointer;min-height:28px;transition:all 0.2s}',
      '.yt-bar:hover{background:rgba(30,20,60,0.7)}',
      '.yt-bar.open{border-radius:10px 10px 0 0;margin-bottom:0}',
      '.yt-bar-icon{width:22px;height:22px;border-radius:5px;background:linear-gradient(135deg,#ff0000,#cc0000);display:flex;align-items:center;justify-content:center;flex-shrink:0}',
      '.yt-bar-icon svg{width:10px;height:10px}',
      '.yt-bar-info{flex:1;min-width:0}',
      '.yt-bar-title{font-size:9px;font-weight:600;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
      '.yt-bar-sub{font-size:7px;color:rgba(255,255,255,0.4)}',
      '.yt-bar-sub.playing{color:rgba(239,68,68,0.7)}',
      '.yt-bar-sub.paused{color:rgba(167,139,250,0.7)}',
      '.yt-bar-btns{display:flex;gap:3px;align-items:center}',
      '.yt-bb{width:18px;height:18px;border-radius:50%;border:none;background:rgba(255,255,255,0.08);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0;transition:background 0.15s}',
      '.yt-bb:hover{background:rgba(255,255,255,0.2)}',
      '.yt-bb svg{width:10px;height:10px}',
      '.yt-eq{display:flex;align-items:center;gap:1px;height:12px;flex-shrink:0}',
      '.yt-eq span{display:block;width:2px;border-radius:1px;background:#ef4444;transition:opacity 0.3s}',
      '@keyframes ye1{0%,100%{height:3px}50%{height:11px}}',
      '@keyframes ye2{0%,100%{height:7px}50%{height:3px}}',
      '@keyframes ye3{0%,100%{height:5px}50%{height:9px}}',
      '.yt-eq.on span:nth-child(1){animation:ye1 .8s ease infinite}',
      '.yt-eq.on span:nth-child(2){animation:ye2 .6s ease infinite .1s}',
      '.yt-eq.on span:nth-child(3){animation:ye3 .7s ease infinite .2s}',
      '.yt-eq.off span{height:4px!important;animation:none;opacity:0.3}',
      '.yt-chev{flex-shrink:0;transition:transform 0.2s}',
      '.yt-chev.flip{transform:rotate(180deg)}',
      '.yt-drawer{background:rgba(15,10,42,0.6);border:1px solid rgba(255,255,255,0.04);border-top:none;border-radius:0 0 10px 10px;padding:8px 10px 10px;margin-bottom:6px}',
      '.yt-search-row{display:flex;gap:4px;margin-bottom:6px}',
      '.yt-search{flex:1;font-size:9px;padding:6px 8px 6px 26px;border-radius:8px;border:1px solid rgba(255,255,255,0.1);background:rgba(255,255,255,0.03);color:#fff;outline:none;font-family:inherit;background-image:url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'12\' height=\'12\' fill=\'none\' stroke=\'rgba(255,255,255,0.25)\' stroke-width=\'2\' viewBox=\'0 0 24 24\'%3E%3Ccircle cx=\'11\' cy=\'11\' r=\'7\'/%3E%3Cpath d=\'M21 21l-4-4\'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:8px center}',
      '.yt-search::placeholder{color:rgba(255,255,255,0.2)}',
      '.yt-search:focus{border-color:rgba(139,92,246,0.4)}',
      '.yt-search-btn{font-size:9px;padding:6px 10px;border-radius:8px;border:none;background:#8b5cf6;color:#fff;font-weight:600;cursor:pointer;white-space:nowrap}',
      '.yt-search-btn:hover{background:#7c3aed}',
      '.yt-section{font-size:7px;font-weight:700;color:rgba(255,255,255,0.3);text-transform:uppercase;letter-spacing:0.4px;margin:6px 0 4px}',
      '.yt-recent{display:flex;align-items:center;gap:6px;padding:4px 2px;border-radius:6px;cursor:pointer;transition:background 0.1s}',
      '.yt-recent:hover{background:rgba(255,255,255,0.04)}',
      '.yt-rc-icon{width:16px;height:16px;border-radius:4px;background:rgba(255,0,0,0.12);display:flex;align-items:center;justify-content:center;flex-shrink:0}',
      '.yt-rc-icon svg{width:7px;height:7px}',
      '.yt-rc-info{flex:1;min-width:0}',
      '.yt-rc-title{font-size:8px;color:rgba(255,255,255,0.6);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
      '.yt-rc-time{font-size:7px;color:rgba(255,255,255,0.2);flex-shrink:0}',
      '.yt-select-row{margin-bottom:6px}',
      '.yt-select{width:100%;font-size:9px;padding:6px 8px;border-radius:8px;border:1px solid rgba(255,255,255,0.1);background:rgba(255,255,255,0.03);color:rgba(255,255,255,0.7);outline:none;font-family:inherit;-webkit-appearance:none;appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'10\' height=\'10\' fill=\'none\' stroke=\'rgba(255,255,255,0.3)\' stroke-width=\'2\' viewBox=\'0 0 24 24\'%3E%3Cpath d=\'M6 9l6 6 6-6\'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:calc(100% - 8px) center;cursor:pointer}',
      '.yt-select:focus{border-color:rgba(139,92,246,0.4)}',
      '.yt-select option{background:#1e1b4b;color:#fff}',
      '.yt-vol-row{display:flex;align-items:center;gap:5px;margin-top:6px;padding-top:6px;border-top:1px solid rgba(255,255,255,0.04)}',
      '.yt-vol-row svg{width:10px;height:10px;flex-shrink:0;color:rgba(255,255,255,0.3)}',
      '.yt-vol{flex:1;height:2px;-webkit-appearance:none;appearance:none;background:rgba(255,255,255,0.1);border-radius:1px;outline:none}',
      '.yt-vol::-webkit-slider-thumb{-webkit-appearance:none;width:8px;height:8px;border-radius:50%;background:#8b5cf6;cursor:pointer}',
      '.yt-frame-hide{position:fixed;bottom:-9999px;left:-9999px;width:200px;height:100px;border:none;opacity:0;pointer-events:none;z-index:-1}',
      '.yt-empty{text-align:center;padding:8px 0;font-size:8px;color:rgba(255,255,255,0.2)}'
    ].join('\n');
    document.head.appendChild(s);
  }

  // ─── Load recents from storage ───
  function loadRecents(cb) {
    try {
      chrome.storage.local.get(['ytRecents'], function(r) {
        _recents = (r.ytRecents || []).slice(0, MAX_RECENTS);
        if (cb) cb();
      });
    } catch(e) { _recents = []; if (cb) cb(); }
  }

  function saveRecents() {
    try { chrome.storage.local.set({ ytRecents: _recents.slice(0, MAX_RECENTS) }); } catch(e) {}
  }

  function addRecent(title, videoId, listId) {
    var key = videoId || listId || '';
    if (!key) return;
    _recents = _recents.filter(function(r) { return (r.videoId || r.listId || '') !== key; });
    _recents.unshift({ title: title, videoId: videoId, listId: listId, time: Date.now() });
    if (_recents.length > MAX_RECENTS) _recents = _recents.slice(0, MAX_RECENTS);
    saveRecents();
    renderRecents();
  }

  // ─── YouTube iframe ───
  function loadVideo(videoId, listId, title) {
    if (_iframe) { try { _iframe.remove(); } catch(e) {} _iframe = null; }

    var src = 'https://www.youtube.com/embed/';
    if (videoId) { src += videoId + '?'; }
    else if (listId) { src += '?listType=playlist&list=' + listId + '&'; }
    else return;

    src += 'enablejsapi=1&autoplay=1&controls=0&rel=0&modestbranding=1&playsinline=1&origin=' + encodeURIComponent(location.origin);
    if (listId && videoId) src += '&list=' + listId;

    _iframe = document.createElement('iframe');
    _iframe.id = 'yt-music-iframe';
    _iframe.className = 'yt-frame-hide';
    _iframe.src = src;
    _iframe.allow = 'autoplay; encrypted-media';
    _iframe.setAttribute('allowfullscreen', '');
    document.body.appendChild(_iframe);

    _ready = false; _playing = false;
    _videoTitle = title || 'Loading...';
    updateUI();

    _iframe.addEventListener('load', function() {
      _ready = true; _playing = true;
      sendCmd('setVolume', [_volume]);
      if (!title || title === 'Loading...') {
        var preset = PRESETS.find(function(p) { return p.listId === listId; });
        _videoTitle = preset ? preset.icon + ' ' + preset.name : 'Playing...';
      }
      updateUI();
      addRecent(_videoTitle, videoId, listId);
    });
  }

  function sendCmd(func, args) {
    if (!_iframe || !_iframe.contentWindow) return;
    try { _iframe.contentWindow.postMessage(JSON.stringify({ event: 'command', func: func, args: args || [] }), '*'); } catch(e) {}
  }

  function extractVideoId(url) {
    if (!url) return null;
    var m = url.match(/[?&]v=([^&#]+)/); if (m) return m[1];
    m = url.match(/youtu\.be\/([^?&#]+)/); if (m) return m[1];
    m = url.match(/embed\/([^?&#]+)/); if (m) return m[1];
    m = url.match(/music\.youtube\.com\/watch\?v=([^&#]+)/); if (m) return m[1];
    if (/^[a-zA-Z0-9_-]{11}$/.test(url.trim())) return url.trim();
    return null;
  }

  function extractPlaylistId(url) {
    if (!url) return null;
    var m = url.match(/[?&]list=([^&#]+)/);
    return m ? m[1] : null;
  }

  function timeAgo(ts) {
    var diff = Math.floor((Date.now() - ts) / 1000);
    if (diff < 60) return 'now';
    if (diff < 3600) return Math.floor(diff / 60) + 'm';
    if (diff < 86400) return Math.floor(diff / 3600) + 'h';
    return Math.floor(diff / 86400) + 'd';
  }

  // ─── Build UI ───
  function buildUI() {
    if (!_container) return;
    injectStyles();

    _container.innerHTML = ''
      + '<div class="yt-bar" id="yt-minibar">'
      +   '<div class="yt-bar-icon"><svg viewBox="0 0 24 24" fill="#fff"><polygon points="10,8 16,12 10,16"/></svg></div>'
      +   '<div class="yt-eq off" id="yt-eq"><span></span><span></span><span></span></div>'
      +   '<div class="yt-bar-info"><div class="yt-bar-title" id="yt-title">Tap to play music</div><div class="yt-bar-sub" id="yt-sub">YouTube Music</div></div>'
      +   '<div class="yt-bar-btns">'
      +     '<button class="yt-bb" id="yt-prev" title="Previous"><svg fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M19 20L9 12l10-8v16z"/><line x1="5" y1="4" x2="5" y2="20"/></svg></button>'
      +     '<button class="yt-bb" id="yt-play" title="Play/Pause"><svg id="yt-play-icon" fill="currentColor" viewBox="0 0 24 24"><polygon points="8,5 19,12 8,19"/></svg></button>'
      +     '<button class="yt-bb" id="yt-next" title="Next"><svg fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M5 4l10 8-10 8V4z"/><line x1="19" y1="4" x2="19" y2="20"/></svg></button>'
      +   '</div>'
      +   '<div class="yt-chev" id="yt-chev"><svg width="10" height="10" fill="none" stroke="rgba(255,255,255,0.25)" stroke-width="2" viewBox="0 0 24 24"><path d="M6 9l6 6 6-6"/></svg></div>'
      + '</div>'
      + '<div class="yt-drawer" id="yt-drawer" style="display:none">'
      +   '<div class="yt-select-row"><select class="yt-select" id="yt-station"><option value="">Select a station...</option></select></div>'
      +   '<div class="yt-search-row">'
      +     '<input class="yt-search" id="yt-search" placeholder="Paste YouTube URL..." />'
      +     '<button class="yt-search-btn" id="yt-search-btn">Play</button>'
      +   '</div>'
      +   '<div class="yt-section" id="yt-recents-label" style="display:none">Recent</div>'
      +   '<div id="yt-recents"></div>'
      +   '<div class="yt-vol-row">'
      +     '<svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M11 5L6 9H2v6h4l5 4V5z"/></svg>'
      +     '<input type="range" class="yt-vol" id="yt-vol" min="0" max="100" value="' + _volume + '" />'
      +   '</div>'
      + '</div>';

    // Station dropdown
    var selectEl = document.getElementById('yt-station');
    PRESETS.forEach(function(p, i) {
      var opt = document.createElement('option');
      opt.value = i;
      opt.textContent = p.icon + '  ' + p.name;
      if (i === _currentPreset) opt.selected = true;
      selectEl.appendChild(opt);
    });
    selectEl.addEventListener('change', function(e) {
      e.stopPropagation();
      var idx = parseInt(selectEl.value);
      if (isNaN(idx)) return;
      _currentPreset = idx;
      var p = PRESETS[idx];
      _videoTitle = p.icon + ' ' + p.name;
      loadVideo('', p.listId, _videoTitle);
    });
    selectEl.addEventListener('click', function(e) { e.stopPropagation(); });
    selectEl.addEventListener('mousedown', function(e) { e.stopPropagation(); });
    selectEl.addEventListener('pointerdown', function(e) { e.stopPropagation(); });
    selectEl.addEventListener('touchstart', function(e) { e.stopPropagation(); });
    // Events
    document.getElementById('yt-minibar').addEventListener('click', toggleDrawer);
    document.getElementById('yt-play').addEventListener('click', function(e) { e.stopPropagation(); togglePlay(); });
    document.getElementById('yt-prev').addEventListener('click', function(e) { e.stopPropagation(); sendCmd('previousVideo'); });
    document.getElementById('yt-next').addEventListener('click', function(e) { e.stopPropagation(); sendCmd('nextVideo'); });
    document.getElementById('yt-search-btn').addEventListener('click', function(e) { e.stopPropagation(); playFromSearch(); });
    document.getElementById('yt-search').addEventListener('keypress', function(e) { if (e.key === 'Enter') { e.stopPropagation(); playFromSearch(); } });
    document.getElementById('yt-search').addEventListener('click', function(e) { e.stopPropagation(); });
    document.getElementById('yt-search').addEventListener('mousedown', function(e) { e.stopPropagation(); });
    document.getElementById('yt-vol').addEventListener('input', function(e) { e.stopPropagation(); _volume = parseInt(e.target.value); sendCmd('setVolume', [_volume]); });
    document.getElementById('yt-vol').addEventListener('click', function(e) { e.stopPropagation(); });
    document.getElementById('yt-vol').addEventListener('mousedown', function(e) { e.stopPropagation(); });

    // YT state messages
    window.addEventListener('message', function(e) {
      if (!e.data || typeof e.data !== 'string') return;
      try {
        var d = JSON.parse(e.data);
        if (d.event === 'infoDelivery' && d.info) {
          if (typeof d.info.playerState !== 'undefined') {
            if (d.info.playerState === 1) { _playing = true; updateUI(); }
            else if (d.info.playerState === 2) { _playing = false; updateUI(); }
            else if (d.info.playerState === 0) { sendCmd('nextVideo'); }
          }
          if (d.info.videoData && d.info.videoData.title) {
            _videoTitle = d.info.videoData.title;
            updateUI();
            addRecent(_videoTitle, '', '');
          }
        }
      } catch(err) {}
    });

    // Load recents and render
    loadRecents(function() { renderRecents(); });
  }

  function toggleDrawer() {
    _expanded = !_expanded;
    var drawer = document.getElementById('yt-drawer');
    var bar = document.getElementById('yt-minibar');
    var chev = document.getElementById('yt-chev');
    if (drawer) drawer.style.display = _expanded ? '' : 'none';
    if (bar) bar.classList.toggle('open', _expanded);
    if (chev) chev.classList.toggle('flip', _expanded);
    if (_expanded) {
      var input = document.getElementById('yt-search');
      if (input) setTimeout(function() { input.focus(); }, 100);
    }
  }

  function renderRecents() {
    var container = document.getElementById('yt-recents');
    var label = document.getElementById('yt-recents-label');
    if (!container) return;

    if (!_recents.length) {
      container.innerHTML = '<div class="yt-empty">No recent plays yet</div>';
      if (label) label.style.display = 'none';
      return;
    }

    if (label) label.style.display = '';
    container.innerHTML = '';
    _recents.forEach(function(r) {
      var row = document.createElement('div');
      row.className = 'yt-recent';
      row.innerHTML = ''
        + '<div class="yt-rc-icon"><svg viewBox="0 0 24 24" fill="#ef4444"><polygon points="10,8 16,12 10,16"/></svg></div>'
        + '<div class="yt-rc-info"><div class="yt-rc-title">' + (r.title || 'Unknown') + '</div></div>'
        + '<div class="yt-rc-time">' + timeAgo(r.time) + '</div>';
      row.addEventListener('click', function(e) {
        e.stopPropagation();
        _videoTitle = r.title || 'Playing...';
        loadVideo(r.videoId || '', r.listId || '', _videoTitle);
      });
      container.appendChild(row);
    });
  }

  function updateUI() {
    var titleEl = document.getElementById('yt-title');
    var subEl = document.getElementById('yt-sub');
    var playIcon = document.getElementById('yt-play-icon');
    var eqEl = document.getElementById('yt-eq');

    if (titleEl) titleEl.textContent = _videoTitle || (_playing ? 'Playing...' : 'Tap to play music');
    if (subEl) {
      subEl.textContent = _playing ? 'Now Playing' : (_ready ? 'Paused' : 'YouTube Music');
      subEl.className = 'yt-bar-sub' + (_playing ? ' playing' : (_ready ? ' paused' : ''));
    }
    if (eqEl) eqEl.className = 'yt-eq ' + (_playing ? 'on' : 'off');
    if (playIcon) {
      playIcon.innerHTML = '';
      if (_playing) {
        var r1 = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
        r1.setAttribute('x','6'); r1.setAttribute('y','5'); r1.setAttribute('width','4'); r1.setAttribute('height','14'); r1.setAttribute('fill','currentColor');
        var r2 = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
        r2.setAttribute('x','14'); r2.setAttribute('y','5'); r2.setAttribute('width','4'); r2.setAttribute('height','14'); r2.setAttribute('fill','currentColor');
        playIcon.appendChild(r1); playIcon.appendChild(r2);
      } else {
        var poly = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
        poly.setAttribute('points','8,5 19,12 8,19'); poly.setAttribute('fill','currentColor');
        playIcon.appendChild(poly);
      }
    }
  }

  function playFromSearch() {
    var input = document.getElementById('yt-search');
    if (!input) return;
    var url = input.value.trim();

    // If no URL typed, check if a station is selected in the dropdown
    if (!url) {
      var sel = document.getElementById('yt-station');
      if (sel && sel.value !== '') {
        var idx = parseInt(sel.value);
        if (!isNaN(idx) && PRESETS[idx]) {
          _currentPreset = idx;
          var p = PRESETS[idx];
          _videoTitle = p.icon + ' ' + p.name;
          loadVideo('', p.listId, _videoTitle);
          if (_expanded) toggleDrawer();
          return;
        }
      }
      return;
    }

    var playlistId = extractPlaylistId(url);
    var videoId = extractVideoId(url);

    if (!videoId && !playlistId) {
      input.style.borderColor = '#ef4444';
      setTimeout(function() { input.style.borderColor = ''; }, 1500);
      return;
    }

    input.value = '';
    _videoTitle = 'Loading...';
    _currentPreset = -1;
    var sel = document.getElementById('yt-station');
    if (sel) sel.value = '';
    updateUI();
    loadVideo(videoId || '', playlistId || '', '');

    if (_expanded) toggleDrawer();
  }

  function togglePlay() {
    if (!_iframe) {
      // First play — start first preset
      _currentPreset = 0;
      var p = PRESETS[0];
      var sel = document.getElementById('yt-station');
      if (sel) sel.value = '0';
      _videoTitle = p.icon + ' ' + p.name;
      loadVideo('', p.listId, _videoTitle);
      return;
    }
    if (_playing) { sendCmd('pauseVideo'); _playing = false; }
    else { sendCmd('playVideo'); _playing = true; }
    updateUI();
  }

  function onCallAnswered() {
    if (_iframe && _playing) {
      _wasPaused = false;
      sendCmd('pauseVideo');
      _playing = false;
      updateUI();
    } else {
      _wasPaused = true;
    }
  }

  function onCallEnded() {
    if (_iframe && !_wasPaused) {
      setTimeout(function() { sendCmd('playVideo'); _playing = true; updateUI(); }, 800);
    }
  }

  return {
    init: function(c) { _container = c; buildUI(); },
    onCallAnswered: onCallAnswered,
    onCallEnded: onCallEnded,
    destroy: function() { if (_iframe) { try { _iframe.remove(); } catch(e) {} _iframe = null; } _ready = false; _playing = false; }
  };
})();
