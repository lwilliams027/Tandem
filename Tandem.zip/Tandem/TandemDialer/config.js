// config.js — Set these once. All agents share the same keys.
const TANDEM_CONFIG = {
  ANTHROPIC_API_KEY: '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',
  DEEPGRAM_API_KEY: 'd1a111431dbb60b45c93ae1b7d9519ce19c56b57',
  AI_MODEL: 'claude-sonnet-4-20250514'
};
