// ═══════════════════════════════════════════════════════
// spotify-minibar.js — Spotify controls for AIL Auto-Dialer overlay
//
// USAGE: Import and call SpotifyMinibar.init(containerEl, serverUrl, authToken)
//        Call SpotifyMinibar.onCallAnswered() when a call connects
//        Call SpotifyMinibar.onCallEnded() when a call terminates
//
// The mini bar auto-pauses on answer and auto-resumes on end.
// ═══════════════════════════════════════════════════════

const SpotifyMinibar = (() => {
  let _server = '';
  let _token = '';
  let _container = null;
  let _connected = false;
  let _isPlaying = false;
  let _pollInterval = null;
  let _wasPlayingBeforeCall = false;
  let _onCallActive = false;

  // ─── CSS (injected once) ───
  const CSS = `
    .spot-bar {
      display: flex; align-items: center; gap: 6px;
      background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
      border-radius: 10px; padding: 6px 10px; margin: 6px 0;
      min-height: 36px; position: relative; overflow: hidden;
      border: 1px solid rgba(29, 185, 84, 0.15);
      transition: all 0.3s ease;
    }
    .spot-bar.playing {
      border-color: rgba(29, 185, 84, 0.4);
      box-shadow: 0 0 12px rgba(29, 185, 84, 0.1);
    }
    .spot-bar.paused-by-call {
      border-color: rgba(255, 170, 0, 0.4);
    }
    .spot-bar.not-connected {
      justify-content: center; cursor: pointer;
    }
    .spot-bar.not-connected:hover {
      border-color: rgba(29, 185, 84, 0.5);
      background: linear-gradient(135deg, #1a1a2e 0%, #1a2e1a 100%);
    }

    .spot-art {
      width: 28px; height: 28px; border-radius: 4px;
      background: #282828; flex-shrink: 0;
      object-fit: cover;
    }
    .spot-art.spinning {
      animation: spot-spin 3s linear infinite;
    }
    @keyframes spot-spin {
      from { border-radius: 50%; } 
      25% { border-radius: 4px; }
      50% { border-radius: 50%; }
      75% { border-radius: 4px; }
      to { border-radius: 50%; }
    }

    .spot-info {
      flex: 1; min-width: 0; overflow: hidden;
    }
    .spot-track {
      font-size: 10px; font-weight: 600; color: #fff;
      white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
      line-height: 1.2;
    }
    .spot-artist {
      font-size: 9px; color: #b3b3b3;
      white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
      line-height: 1.2;
    }

    .spot-controls {
      display: flex; align-items: center; gap: 2px; flex-shrink: 0;
    }
    .spot-btn {
      background: none; border: none; cursor: pointer;
      color: #b3b3b3; padding: 2px; display: flex;
      align-items: center; justify-content: center;
      border-radius: 50%; width: 22px; height: 22px;
      transition: all 0.15s;
    }
    .spot-btn:hover { color: #fff; background: rgba(255,255,255,0.1); }
    .spot-btn.play-btn { color: #1DB954; width: 26px; height: 26px; }
    .spot-btn.play-btn:hover { color: #1ed760; transform: scale(1.1); }

    .spot-connect-text {
      font-size: 11px; color: #1DB954; font-weight: 600;
      display: flex; align-items: center; gap: 6px;
    }
    .spot-connect-text svg { flex-shrink: 0; }

    .spot-paused-label {
      font-size: 8px; color: #ffaa00; font-weight: 600;
      position: absolute; top: 2px; right: 6px;
      text-transform: uppercase; letter-spacing: 0.5px;
    }

    .spot-disconnect {
      font-size: 8px; color: #666; cursor: pointer;
      position: absolute; top: 2px; right: 6px;
    }
    .spot-disconnect:hover { color: #ff4444; }

    .spot-progress {
      position: absolute; bottom: 0; left: 0; height: 2px;
      background: #1DB954; border-radius: 0 0 10px 10px;
      transition: width 1s linear;
    }
  `;

  // ─── SVG Icons ───
  const ICONS = {
    spotify: `<svg width="16" height="16" viewBox="0 0 24 24" fill="#1DB954"><path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z"/></svg>`,
    play: `<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>`,
    pause: `<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>`,
    next: `<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z"/></svg>`,
    prev: `<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M6 6h2v12H6zm3.5 6l8.5 6V6z"/></svg>`,
  };

  // ─── Inject CSS ───
  function injectCSS() {
    if (document.getElementById('spot-minibar-css')) return;
    const style = document.createElement('style');
    style.id = 'spot-minibar-css';
    style.textContent = CSS;
    document.head.appendChild(style);
  }

  // ─── API helpers ───
  async function api(path, method = 'GET', body = null) {
    try {
      const opts = {
        method,
        headers: { 'Authorization': `Bearer ${_token}`, 'Content-Type': 'application/json' }
      };
      if (body) opts.body = JSON.stringify(body);
      const r = await fetch(`${_server}${path}`, opts);
      return await r.json();
    } catch (e) {
      console.warn('[Spotify]', path, e.message);
      return { ok: false };
    }
  }

  // ─── Render: Not Connected ───
  function renderDisconnected() {
    _container.innerHTML = `
      <div class="spot-bar not-connected" id="spotConnect">
        <span class="spot-connect-text">
          ${ICONS.spotify} Connect Spotify
        </span>
      </div>
    `;
    _container.querySelector('#spotConnect').addEventListener('click', connectSpotify);
  }

  // ─── Render: Connected ───
  function renderPlayer(data) {
    const playing = data.is_playing;
    const paused = _onCallActive && _wasPlayingBeforeCall;
    const progress = data.duration_ms > 0 ? (data.progress_ms / data.duration_ms * 100) : 0;

    _container.innerHTML = `
      <div class="spot-bar ${playing ? 'playing' : ''} ${paused ? 'paused-by-call' : ''}">
        ${data.album_art
          ? `<img class="spot-art ${playing ? 'spinning' : ''}" src="${data.album_art}" alt="">`
          : `<div class="spot-art"></div>`
        }
        <div class="spot-info">
          <div class="spot-track">${data.track || 'No track'}</div>
          <div class="spot-artist">${data.artist || 'Unknown'}</div>
        </div>
        <div class="spot-controls">
          <button class="spot-btn" id="spotPrev" title="Previous">${ICONS.prev}</button>
          <button class="spot-btn play-btn" id="spotPlayPause" title="${playing ? 'Pause' : 'Play'}">
            ${playing ? ICONS.pause : ICONS.play}
          </button>
          <button class="spot-btn" id="spotNext" title="Next">${ICONS.next}</button>
        </div>
        ${paused ? '<div class="spot-paused-label">On Call</div>' : ''}
        ${!paused ? '<div class="spot-disconnect" id="spotDisconnect" title="Disconnect Spotify">✕</div>' : ''}
        <div class="spot-progress" style="width: ${progress}%"></div>
      </div>
    `;

    // Bind buttons
    _container.querySelector('#spotPlayPause')?.addEventListener('click', togglePlayPause);
    _container.querySelector('#spotNext')?.addEventListener('click', () => api('/api/spotify/next', 'POST').then(poll));
    _container.querySelector('#spotPrev')?.addEventListener('click', () => api('/api/spotify/previous', 'POST').then(poll));
    _container.querySelector('#spotDisconnect')?.addEventListener('click', disconnect);
  }

  // ─── Render: No Active Device ───
  function renderInactive() {
    _container.innerHTML = `
      <div class="spot-bar">
        <div class="spot-art"></div>
        <div class="spot-info">
          <div class="spot-track" style="color:#b3b3b3">Open Spotify on any device</div>
          <div class="spot-artist">Then play something to connect</div>
        </div>
        <div class="spot-disconnect" id="spotDisconnect" title="Disconnect">✕</div>
      </div>
    `;
    _container.querySelector('#spotDisconnect')?.addEventListener('click', disconnect);
  }

  // ─── Actions ───
  async function connectSpotify() {
    const data = await api('/api/spotify/login');
    if (data.auth_url) {
      const popup = window.open(data.auth_url, 'spotify_auth', 'width=450,height=700,left=200,top=100');
      // Listen for callback
      window.addEventListener('message', function onMsg(e) {
        if (e.data?.type === 'spotify-connected') {
          window.removeEventListener('message', onMsg);
          _connected = true;
          poll();
          startPolling();
        }
      });
    }
  }

  async function togglePlayPause() {
    if (_isPlaying) {
      await api('/api/spotify/pause', 'POST');
    } else {
      await api('/api/spotify/play', 'POST');
    }
    // Small delay for Spotify to update state
    setTimeout(poll, 300);
  }

  async function disconnect() {
    await api('/api/spotify/disconnect', 'POST');
    _connected = false;
    _isPlaying = false;
    stopPolling();
    renderDisconnected();
  }

  // ─── Polling ───
  async function poll() {
    if (!_connected) return;
    const data = await api('/api/spotify/player');
    if (!data.ok && !data.connected) {
      _connected = false;
      renderDisconnected();
      stopPolling();
      return;
    }
    if (!data.active) {
      renderInactive();
      return;
    }
    _isPlaying = data.is_playing;
    renderPlayer(data);
  }

  function startPolling() {
    stopPolling();
    poll();
    // Poll every 3 seconds (Spotify rate limit is generous for player state)
    _pollInterval = setInterval(poll, 3000);
  }

  function stopPolling() {
    if (_pollInterval) clearInterval(_pollInterval);
    _pollInterval = null;
  }

  // ─── Call State Hooks ───
  async function onCallAnswered() {
    _onCallActive = true;
    if (_isPlaying) {
      _wasPlayingBeforeCall = true;
      await api('/api/spotify/pause', 'POST');
      _isPlaying = false;
      setTimeout(poll, 300);
      console.log('[Spotify] Auto-paused for call');
    } else {
      _wasPlayingBeforeCall = false;
    }
  }

  async function onCallEnded() {
    _onCallActive = false;
    if (_wasPlayingBeforeCall) {
      // Small delay to let the call fully terminate
      setTimeout(async () => {
        await api('/api/spotify/play', 'POST');
        _wasPlayingBeforeCall = false;
        _isPlaying = true;
        setTimeout(poll, 500);
        console.log('[Spotify] Auto-resumed after call');
      }, 800);
    } else {
      _wasPlayingBeforeCall = false;
      poll();
    }
  }

  // ─── Init ───
  async function init(containerEl, serverUrl, authToken) {
    _container = containerEl;
    _server = serverUrl.replace(/\/$/, '');
    _token = authToken;

    injectCSS();

    // Check if connected
    const status = await api('/api/spotify/status');
    if (!status.configured) {
      // Spotify not configured on server — hide the bar
      _container.style.display = 'none';
      return;
    }

    _connected = status.connected;

    if (_connected) {
      startPolling();
    } else {
      renderDisconnected();
    }
  }

  // ─── Public API ───
  return {
    init,
    onCallAnswered,
    onCallEnded,
    poll,
    isConnected: () => _connected,
    isPlaying: () => _isPlaying,
  };
})();

// Export for both module and global usage
if (typeof module !== 'undefined' && module.exports) {
  module.exports = SpotifyMinibar;
}
