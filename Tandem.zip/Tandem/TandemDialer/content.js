window.addEventListener("error",function(e){if(e&&e.message&&e.message.indexOf("Extension context invalidated")>=0){e.preventDefault();return true}});
!function(){"use strict";const t={plivoReady:!1,frame:null,lead:null,callEnded:!1,manualAnswer:!1,liveCall:!1,stopped:!1,currentUUID:null,dialAbort:null,muted:!1,apptNames:new Set,cfg:{serverUrl:"https://tandemdialer.com",agentIdentity:"",apiKey:"",dialApiKey:"",supabaseEmail:"",supabasePassword:"",doubleTap:!0,autoMute:!0,skipAppts:!0},stats:{calls:0,answered:0,voicemail:0,noAnswer:0}};function e(t,e="info"){console.log("[AIL]",t)}function n(t,e){const n=document.getElementById("ail-status");n&&(n.textContent=t,n.className="ail-status-text state-"+e);const i=document.querySelector(".ail-phone-screen");i&&(i.className="ail-phone-screen state-"+e);const s=document.getElementById("ail-mini-status");s&&(s.textContent=t);const l=document.getElementById("ail-mini-bar");l&&(l.style.background="connected"===e?"linear-gradient(135deg,#064e3b,#059669)":"error"===e?"linear-gradient(135deg,#7f1d1d,#991b1b)":"dialing"===e?"linear-gradient(135deg,#4c1d95,#7c3aed)":"linear-gradient(135deg,#1e1b4b,#0f0a2a)"),a()}function a(){const e=document.getElementById("ail-mini-mute");e&&(e.className="ail-mini-circle mute-btn"+(t.muted?"":" unmuted"))}function i(){["calls","answered","vm","na"].forEach((e,n)=>{const a=document.getElementById("ail-stat-"+e);a&&(a.textContent=[t.stats.calls,t.stats.answered,t.stats.voicemail,t.stats.noAnswer][n])})}function s(t){return new Promise(e=>setTimeout(e,t))}async function l(){return new Promise(e=>{chrome.storage.local.get(["ailSettings"],n=>{n.ailSettings&&Object.assign(t.cfg,n.ailSettings),e()})})}async function o(){return(await chrome.storage.local.get(["ailStep"])).ailStep||{step:0,running:!1,stats:{calls:0,answered:0,voicemail:0,noAnswer:0}}}async function r(t){const e=await o();Object.assign(e,t),await chrome.storage.local.set({ailStep:e})}async function c(n){if(!n)try{const t=await chrome.storage.local.get(["sbToken"]);if(t.sbToken)return t.sbToken}catch(t){}if(t.cfg.supabaseEmail&&t.cfg.supabasePassword)try{e("Refreshing login token...","info");const n=await fetch(t.cfg.serverUrl+"/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email:t.cfg.supabaseEmail,password:t.cfg.supabasePassword})}),a=await n.json();if(a.ok&&a.access_token)return await chrome.storage.local.set({sbToken:a.access_token}),e("Token refreshed","ok"),a.access_token;e("Token refresh failed: "+(a.error||""),"err")}catch(t){e("Token refresh error: "+t.message,"err")}return null}function d(){return/\/Lead\/(InboxDetail|Detail)/i.test(location.href)}function u(){return location.href.includes("/WhatHappend")}function m(){const t=location.search.match(/LeadId=(\d+)/i);return t?t[1]:null}function p(){const t={id:m(),name:"",phone:"",mobile:"",home:"",is_dnc:!1};try{let e="";const n=document.querySelector('a[href*="LeadEdit"]');if(n&&(e=n.textContent.trim()),e||document.querySelectorAll('a[href*="LeadEdit"], .fa-pencil, [class*="edit"]').forEach(t=>{const n=t.closest("div,td,span");if(n){const t=n.textContent.trim().split("\n")[0].trim();t.includes(",")&&t.length>3&&t.length<60&&(e=t)}}),!e)for(const t of document.querySelectorAll("b,strong,h1,h2,h3,h4")){const n=t.textContent.trim();if(n.includes(",")&&n.length>3&&n.length<60&&!/Comments|Status|History|REFERRAL|Language|Mobile|Home|Email|Anchor|INBOX/i.test(n)){e=n;break}}if(!e){const t=document.querySelectorAll("div,td,span");for(const n of t){const t=n.textContent.trim(),a=n.getBoundingClientRect();if(a.top<350&&a.top>80&&t.includes(",")&&t.length>3&&t.length<50&&/^[A-Z]/.test(t)&&!/Comments|Status|History|Language|Mobile|Home|Email|INBOX/i.test(t)&&n.children.length<3){e=t.split("\n")[0].trim();break}}}if(e){if(e.includes(",")){const n=e.split(",");t.name=(n[1]||"").trim()+" "+(n[0]||"").trim()}else t.name=e;t.name=t.name.replace(/\b\w/g,t=>t.toUpperCase()).replace(/\b(\w)(\w+)/g,(t,e,n)=>e+n.toLowerCase())}if(t.name||(t.name="Lead "+(t.id||"?")),document.querySelectorAll('a[href^="tel:"]').forEach(e=>{const n=e.href.replace("tel:","").replace(/\D/g,""),a=(e.previousSibling?.textContent||"")+(e.parentElement?.textContent||"");/mobile/i.test(a)?t.mobile=n:/home/i.test(a)?t.home=n:t.home||(t.home=n)}),!t.mobile&&!t.home){const e=document.body.innerText.match(/\d{3}[-.)]\s?\d{3}[-.]?\d{4}/g);e&&(t.home=e[0].replace(/\D/g,""),e[1]&&(t.mobile=e[1].replace(/\D/g,"")))}t.mobile&&t.mobile.length>=10?t.phone=f(t.mobile):t.home&&t.home.length>=10&&(t.phone=f(t.home)),document.body.innerText.toUpperCase().includes("DO NOT CALL")&&(t.is_dnc=!0);const a=document.body.innerText.match(/(\d+)\s*\/\s*(\d+)/);a&&(t.idx=+a[1],t.total=+a[2])}catch(t){}return t}function f(t){const e=t.replace(/\D/g,"");return 10===e.length?"+1"+e:(11===e.length&&e[0],"+"+e)}async function g(t){try{const e=await chrome.runtime.sendMessage({type:"clickInPage",selector:t});return e&&e.ok}catch(t){return!1}}async function h(){let t="#cellPhCallButton";return document.getElementById("cellPhCallButton")||document.getElementById("phoneCallButton")&&(t="#phoneCallButton"),e("Clicking call button ("+t+")...","info"),await g(t)}function w(){for(const t of document.querySelectorAll("a")){const n=t.textContent.trim();if(n.startsWith("No Answer")||n.includes("No Answer:"))return t.scrollIntoView({block:"center"}),t.click(),e("✓ No Answer clicked","ok"),!0}return e("No Answer not found","warn"),!1}function y(e){if(e&&e.type==="ail-hangup"&&t.liveCall){console.log("[AIL] Blocked hangup — live call active");return}t.frame&&t.frame.contentWindow&&t.frame.contentWindow.postMessage(e,"*")}async function v(){if(t.plivoReady)return!0;let n=await c();if(!n)return e("Need login","err"),!1;try{let a=await fetch(t.cfg.serverUrl+"/token",{headers:{Authorization:"Bearer "+n}});if(401===a.status||403===a.status){if(e("Token expired — refreshing...","warn"),n=await c(!0),!n)return e("Could not refresh token","err"),!1;a=await fetch(t.cfg.serverUrl+"/token",{headers:{Authorization:"Bearer "+n}})}const i=await a.json();if(i.error)throw new Error(i.error);!function(){if(t.frame)return;const e=document.createElement("iframe");e.id="ail-dialer-iframe",e.src=t.cfg.serverUrl+"/extension-dialer",e.setAttribute("allow","microphone *; autoplay *"),e.style.cssText="width:300px;height:40px;position:fixed;bottom:0;left:10px;border:1px solid #333;border-radius:8px 8px 0 0;z-index:999998;background:#1a1a2e",document.body.appendChild(e),t.frame=e}();let l=!1;const o=t=>{t.data&&"ail-loaded"===t.data.type&&(l=!0)};window.addEventListener("message",o);for(let t=0;t<10&&!l;t++)await s(500);window.removeEventListener("message",o),y({type:"ail-init",username:i.endpoint_username,password:i.endpoint_password});let r=0;for(;!t.plivoReady&&r<30;)await s(500),r++;return t.plivoReady}catch(t){return e("Plivo err: "+t.message,"err"),!1}}async function b(n,a){try{const e=new AbortController;t.dialAbort=e;const i=setTimeout(()=>e.abort(),25e3),s=await c(),l=await fetch(t.cfg.serverUrl+"/dial",{method:"POST",headers:{"Content-Type":"application/json","X-API-KEY":t.cfg.apiKey||t.cfg.dialApiKey||"",Authorization:"Bearer "+(s||"")},body:JSON.stringify({to:n,lead_name:a,agent_identity:t.cfg.agentIdentity||"agent_browser"}),signal:e.signal});clearTimeout(i),t.dialAbort=null;const o=await l.json();if(!o.ok)throw new Error(o.error||"fail");return t.currentUUID=o.call_uuid,o.call_uuid}catch(n){return t.dialAbort=null,"AbortError"===n.name?(e("Dial aborted","warn"),null):(e("Dial err: "+n.message,"err"),null)}}async function x(force){if(t.liveCall&&!force){console.log("[AIL] Blocked x() hangup — live call");return}if(t.dialAbort){try{t.dialAbort.abort()}catch(t){}t.dialAbort=null}if(y({type:"ail-hangup"}),t.currentUUID){const e=t.currentUUID;t.currentUUID=null;try{const n=await c();fetch(t.cfg.serverUrl+"/hangup",{method:"POST",headers:{"Content-Type":"application/json",Authorization:"Bearer "+(n||"")},body:JSON.stringify({call_uuid:e})}).catch(()=>{})}catch(t){}}}async function k(e){try{const n=await c();if(!n)return;const a={dials:0,answered:0,voicemail:0,no_answer:0};if("answered"===e)a.answered=1;else if("voicemail"===e)a.voicemail=1;else{if("no_answer"!==e)return;a.no_answer=1}fetch(t.cfg.serverUrl+"/report-usage",{method:"POST",headers:{"Content-Type":"application/json",Authorization:"Bearer "+n},body:JSON.stringify(a)}).catch(()=>{})}catch(t){}}async function E(){try{const a=await c();if(!a)return e("No token — cannot check limits","err"),!1;const i=await fetch(t.cfg.serverUrl+"/api/usage",{headers:{Authorization:"Bearer "+a}}),s=await i.json();return s.ok?0===s.dials_remaining?(e("⛔ Daily dial limit reached!","err"),n("Daily limit reached","error"),!1):(s.dials_remaining>0&&e(`Dials remaining today: ${s.dials_remaining}`,"info"),!0):(e("Usage check failed","err"),!0)}catch(t){return!0}}async function I(n){t.callEnded=!1,t.manualAnswer=!1,t.liveCall=!1;let a=-1;!function(){const t=document.getElementById("ail-answered-btn");t&&(t.style.display="flex")}(),function(){const t=document.getElementById("ail-mute-btn");t&&(t.style.display="")}(),!1!==t.cfg.autoMute?(D(!0),e("Auto-muted while ringing","info")):(D(!1),e("Mic live (auto-mute off)","info"));for(let i=0;i<80;i++){if(await s(800),t.liveCall)return"answered";if(t.stopped)return M(),_(),y({type:"ail-hangup"}),e("Call aborted","warn"),"stopped";if(t.manualAnswer)return e("Agent confirmed: ANSWERED!","ok"),M(),D(!1),O(),t.liveCall=!0,"answered";if(t.callEnded){if(a>=0){M(),e("Call ended after pickup — checking status...","info"),await s(2e3);try{const i=await fetch(t.cfg.serverUrl+"/call-info/"+n),s=await i.json(),l=parseInt(s.duration)||0,o=a>=0;return e("Final: dur="+l+"s amd="+s.amd_result+" picked_up="+o+" dial="+s.dial_status,"info"),o?"true"===s.amd_result?(_(),R(),"voicemail"):"false"===s.amd_result||l>=8?(D(!1),O(),t.liveCall=!0,"answered"):l>=3?(_(),R(),"voicemail"):(D(!1),O(),t.liveCall=!0,"answered"):(s.dial_status&&s.dial_status,_(),R(),"no_answer")}catch(t){}return _(),R(),"no_answer"}return M(),_(),R(),"no_answer"}try{const s=await fetch(t.cfg.serverUrl+"/call-info/"+n),l=await s.json();if(l.completed){M();const n=parseInt(l.duration)||0,i=a>=0;return e("Completed: dur="+n+"s amd="+l.amd_result+" picked_up="+i+" dial="+l.dial_status,"info"),i?"true"===l.amd_result?(_(),R(),"voicemail"):"false"===l.amd_result||n>=8?(D(!1),O(),t.liveCall=!0,"answered"):n>=3?(_(),R(),"voicemail"):(D(!1),O(),t.liveCall=!0,"answered"):(l.dial_status&&l.dial_status,_(),R(),"no_answer")}if("in-progress"===l.live_status){if(a<0&&(a=i,e("Call picked up — waiting for AMD...","info")),"true"===l.amd_result)return M(),e("Voicemail (AMD after pickup)","warn"),y({type:"ail-hangup"}),_(),R(),"voicemail";if("false"===l.amd_result)return M(),e("Lead answered! (AMD=human)","ok"),D(!1),O(),t.liveCall=!0,"answered";const n=i-a;if(n>=3)return M(),e("Lead answered! (no AMD after "+Math.round(.8*n)+"s)","ok"),D(!1),O(),t.liveCall=!0,"answered"}if("false"===l.amd_result&&a>=0)return M(),e("Human (AMD confirmed)","ok"),D(!1),O(),t.liveCall=!0,"answered";if(l.dial_status&&"completed"!==l.dial_status)return M(),e("No answer: "+l.dial_status,"warn"),_(),R(),"no_answer"}catch(t){}}return M(),y({type:"ail-hangup"}),_(),R(),"no_answer"}
async function A(){try{const e=await chrome.storage.local.get(["ailApptNames"]);if(e.ailApptNames&&e.ailApptNames.length>0)return"string"==typeof e.ailApptNames[0]?t.apptNames=new Set(e.ailApptNames):t.apptNames=new Set(e.ailApptNames.map(t=>t.name)),!0}catch(t){}return!1}function C(t){return t.toLowerCase().replace(/[^a-z\s]/g,"").replace(/\s+/g," ").trim()}function T(){t.callStart=Date.now();const e=document.getElementById("ail-timer");e&&(e.style.display="block"),t.timerInt=setInterval(()=>{const e=Math.floor((Date.now()-t.callStart)/1e3),n=document.getElementById("ail-timer");n&&(n.textContent=String(Math.floor(e/60)).padStart(2,"0")+":"+String(e%60).padStart(2,"0"))},1e3)}function B(){t.timerInt&&clearInterval(t.timerInt),t.timerInt=null;const e=document.getElementById("ail-timer");e&&(e.textContent="00:00",e.style.display="none")}async function S(){await l();const a=await o();if(!a.running)return;t.stopped=!1,Object.assign(t.stats,a.stats||{}),i(),z();const c=a.step||0,f=d(),y=u();if(e(`── Step ${c} | ${f?"DETAIL":y?"WHATHAPPEND":"OTHER"} ──`,"info"),0===c&&f){if(await s(100),t.stopped)return;const a=p();if(t.lead=a,q(a),!a.phone)return e("No phone — skipping lead","warn"),await r({step:6,stats:t.stats}),void await S();if(a.is_dnc)return e("⛔ DNC — skipping","warn"),await r({step:6,stats:t.stats}),void await S();if(!1!==t.cfg.skipAppts&&function(e){if(!t.apptNames||0===t.apptNames.size)return!1;const n=C(e);if(!n||n.length<3)return!1;if(t.apptNames.has(n))return!0;const a=n.split(" ");if(a.length>=2){const e=a.slice(1).join(" ")+" "+a[0];if(t.apptNames.has(e))return!0;for(const e of t.apptNames){const t=e.split(" ");if(t.length>=2&&a.length>=2){if(a[a.length-1]===t[t.length-1]&&a[0][0]===t[0][0])return!0;if(a[0]===t[t.length-1]&&a[a.length-1][0]===t[0][0])return!0}}}return!1}(a.name))return e("Booked appointment — skipping "+a.name,"warn"),n("Appt — skipping","idle"),await s(800),await r({step:6,stats:t.stats}),void await S();if(t.stopped)return;if(!await E())return;if(!await v())return void e("Plivo failed","err");if(t.stopped)return;t.stats.calls++,i(),e(`📞 Attempt #1: ${a.name} at ${a.phone}`,"info"),U(),n("Ringing...","dialing");const l=await b(a.phone,a.name);let o="no_answer";return l?(o=await I(l),t._lastCallUUID=l,t.currentUUID=null):e("Dial failed — treating as no answer","warn"),e("Result: "+o,"info"),"stopped"===o?(t.stats.calls--,void i()):(k(o),"answered"===o?(t.stats.answered++,i(),await r({step:6,stats:t.stats,leadId:a.id}),_connectedAtStep=c||0,e("✅ ANSWERED! Talk, log in Impact, click RESUME.","ok"),n("Connected","connected"),t.liveCall=!0,N(),void T()):("voicemail"===o?(t.stats.voicemail++,i()):(t.stats.noAnswer++,i()),await r({step:1,stats:t.stats,leadId:a.id}),e("Going to log No Answer...","info"),await h(),await s(3e3),void(u()||(e("Call button didn't navigate — trying step 2 directly","warn"),t.cfg.doubleTap?(await r({step:3,stats:t.stats,leadId:a.id}),await S()):(await r({step:6,stats:t.stats,leadId:a.id}),await S())))))}if(1===c){if(y){await s(2e3),w(),await s(1500);const e=a.leadId||m();return t.cfg.doubleTap?await r({step:3,leadId:e}):await r({step:6,leadId:e}),void(e&&(window.location.href="https://mobile.impact.ailife.com/Lead/InboxDetail?LeadId="+e+"&detailId=-1"))}return f?(e("Not on WhatHappend — skipping log","warn"),void(t.cfg.doubleTap?(await r({step:3,stats:t.stats,leadId:a.leadId}),await S()):(await r({step:6,stats:t.stats,leadId:a.leadId}),await S()))):void 0}if(3===c&&f){if(await s(300),t.stopped)return;const a=p();if(t.lead=a,q(a),!a.phone)return await r({step:6,stats:t.stats}),void await S();if(t.stopped)return;if(!await E())return;if(!await v())return void e("Plivo failed","err");if(t.stopped)return;t.stats.calls++,i(),e(`📞 Attempt #2 (double-tap): ${a.name}`,"info"),U(),n("Ringing...","dialing");const l=await b(a.phone,a.name);let o="no_answer";return l?(o=await I(l),t._lastCallUUID=l,t.currentUUID=null):e("Dial failed — treating as no answer","warn"),e("Result: "+o,"info"),"stopped"===o?(t.stats.calls--,void i()):(k(o),"answered"===o?(t.stats.answered++,i(),await r({step:6,stats:t.stats,leadId:a.id}),_connectedAtStep=c||0,e("✅ ANSWERED! Talk, log in Impact, click RESUME.","ok"),n("Connected","connected"),t.liveCall=!0,N(),void T()):("voicemail"===o?(t.stats.voicemail++,i()):(t.stats.noAnswer++,i()),await r({step:4,stats:t.stats,leadId:a.id}),e("Going to log No Answer #2...","info"),await h(),await s(3e3),void(u()||(e("Call btn didn't navigate — advancing","warn"),await r({step:6,stats:t.stats,leadId:a.id}),await S()))))}if(4===c){if(y){await s(2e3),w(),await s(1500);const t=a.leadId||m();return await r({step:6,leadId:t}),void(t&&(window.location.href="https://mobile.impact.ailife.com/Lead/InboxDetail?LeadId="+t+"&detailId=-1"))}return f?(e("Not on WH — advancing","warn"),await r({step:6,stats:t.stats}),void await S()):void 0}if(c>=6&&f)return e("⏭️ Advancing to next lead...","info"),await r({step:0,stats:t.stats}),await s(1e3),void(await async function(){for(const t of document.querySelectorAll("a,button"))if((t.getAttribute("onclick")||"").includes("MoveNext")){const n="ail-mn-"+Date.now();return t.id=n,e("Clicking MoveNext...","info"),await g("#"+n)}return e("MoveNext not found","warn"),!1}()||e("MoveNext failed — click manually","warn"));e("Waiting for correct page (step="+c+")...","info")}function N(){const t=document.getElementById("ail-resume-btn");t&&(t.style.display="block")}function L(){const t=document.getElementById("ail-resume-btn");t&&(t.style.display="none")}function M(){const t=document.getElementById("ail-answered-btn");t&&(t.style.display="none")}function _(){}function D(e){t.muted=e,y({type:e?"ail-mute":"ail-unmute"});const n=document.getElementById("ail-mute-btn");if(!n)return;e?n.classList.add("muted"):n.classList.remove("muted");a()}function P(){D(!t.muted)}function U(){try{const t=new(window.AudioContext||window.webkitAudioContext),b=t.createBuffer(1,t.sampleRate*0.06,t.sampleRate),d=b.getChannelData(0);for(var i=0;i<d.length;i++){d[i]=(Math.random()*2-1)*Math.exp(-i/(d.length*0.12))}var s=t.createBufferSource();s.buffer=b;var f=t.createBiquadFilter();f.type="highpass";f.frequency.value=2500;var g=t.createGain();g.gain.value=0.15;s.connect(f);f.connect(g);g.connect(t.destination);s.start()}catch(t){}}function O(){try{const t=new(window.AudioContext||window.webkitAudioContext);function _pop(when){var b=t.createBuffer(1,t.sampleRate*0.04,t.sampleRate),d=b.getChannelData(0);for(var i=0;i<d.length;i++){d[i]=(Math.random()*2-1)*Math.pow(1-i/d.length,8)}var s=t.createBufferSource();s.buffer=b;var g=t.createGain();g.gain.value=0.3;s.connect(g);g.connect(t.destination);s.start(when)}_pop(t.currentTime);_pop(t.currentTime+0.12);_pop(t.currentTime+0.24)}catch(t){}}function R(){try{const t=new(window.AudioContext||window.webkitAudioContext),b=t.createBuffer(1,t.sampleRate*0.15,t.sampleRate),d=b.getChannelData(0);for(var i=0;i<d.length;i++){d[i]=(Math.random()*2-1)*Math.pow(1-i/d.length,4)*0.5}var s=t.createBufferSource();s.buffer=b;var f=t.createBiquadFilter();f.type="lowpass";f.frequency.value=200;var g=t.createGain();g.gain.value=0.4;s.connect(f);f.connect(g);g.connect(t.destination);s.start()}catch(t){}}async function H(){L(),_(),B(),D(!1),t.liveCall=!1,e("▶ Resuming...","ok"),await S()}function q(t){const e=document.getElementById("ail-lead-info");if(!e)return;const n=(t.name||"?").split(" ").map(t=>t[0]).join("").substring(0,2).toUpperCase();e.innerHTML=`<div class="ail-avatar"><img src="${chrome.runtime.getURL('icons/icon128.png')}" style="width:32px;height:32px;border-radius:4px"></div><div class="ail-lead-name">${t.name||"No Lead"}</div><div class="ail-lead-phone">${t.phone||t.mobile||t.home||""}</div><div class="ail-lead-detail">${t.idx?"Lead "+t.idx+"/"+t.total:""}</div>`;const a=document.getElementById("ail-mini-name");a&&(a.textContent=t.name||"No Lead");const i=document.getElementById("ail-mini-avatar");i&&(i.innerHTML='<img src="'+chrome.runtime.getURL('icons/icon128.png')+'" style="width:20px;height:20px;border-radius:3px">')}function z(){const t=document.getElementById("ail-start-btn-hidden");t&&(t.disabled=!0);const e=document.getElementById("ail-pause-btn");e&&(e.disabled=!1);const n=document.getElementById("ail-stop-btn");n&&(n.disabled=!1)}function j(){if(document.getElementById("ail-dialer-panel"))return;const n=document.createElement("div");n.id="ail-dialer-panel",n.innerHTML='\n<div class="ail-phone-screen" id="ail-drag-handle">\n  <div class="ail-phone-status-bar"><img src="'+chrome.runtime.getURL("icons/tandem_white.png")+'" style="height:14px;vertical-align:middle"><span class="ail-agent-name" id="ail-agent-name"></span><button class="ail-min-btn" id="ail-min">\u2212</button></div>\n  <div class="ail-phone-body" id="ail-phone-body">\n    <div class="ail-caller-area" id="ail-lead-info">\n      <div class="ail-avatar" id="ail-avatar"></div>\n      <div class="ail-lead-name">No Lead</div>\n      <div class="ail-lead-phone"></div>\n      <div class="ail-lead-detail"></div>\n    </div>\n    <div id="ail-status" class="ail-status-text">Ready</div>\n    <div id="ail-timer" class="ail-timer" style="display:none">00:00</div>\n    <div class="ail-btn-row">\n      <div class="ail-btn-col"><div class="ail-rbtn ail-rbtn-mute" id="ail-mute-btn"><svg class="ail-icon-unmuted" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M19.07 4.93a10 10 0 010 14.14M15.54 8.46a5 5 0 010 7.07"/></svg><svg class="ail-icon-muted" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M11 5L6 9H2v6h4l5 4V5z"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg></div><div class="ail-rbtn-label">Mute</div></div>\n      <div class="ail-btn-col"><div class="ail-rbtn ail-rbtn-center" id="ail-center-btn"><span id="ail-icon-play" style="display:flex;align-items:center;justify-content:center"><img src="'+chrome.runtime.getURL("icons/play_icon.png")+'" style="width:30px;height:30px;object-fit:contain;margin-left:2px"></span><span id="ail-icon-answer" style="display:none;align-items:center;justify-content:center"><img src="'+chrome.runtime.getURL("icons/answer_icon.png")+'" style="width:30px;height:30px;object-fit:contain"></span><span id="ail-icon-hangup" style="display:none;align-items:center;justify-content:center"><img src="'+chrome.runtime.getURL("icons/hangup_icon.png")+'" style="width:30px;height:30px;object-fit:contain"></span><span id="ail-icon-resume" style="display:none;align-items:center;justify-content:center"><img src="'+chrome.runtime.getURL("icons/play_icon.png")+'" style="width:30px;height:30px;object-fit:contain;margin-left:2px"></span></div><div class="ail-rbtn-label" id="ail-center-label">Start</div></div>\n      <div class="ail-btn-col"><div class="ail-rbtn ail-rbtn-stop" id="ail-stop-btn"><svg width="14" height="14" fill="currentColor" viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16" rx="2"/></svg></div><div class="ail-rbtn-label">Stop</div></div>\n    </div>\n  </div>\n  <div class="ail-phone-bottom">\n    <div id="ail-sync-bar" class="ail-sync-bar" style="display:none"></div>\n    <button id="ail-start-btn-hidden" style="display:none"></button>\n    <button id="ail-pause-btn" style="display:none"></button>\n    <button id="ail-resume-btn" style="display:none"></button>\n    <div id="ail-answered-btn" style="display:none"></div>\n    <button id="ail-sync-btn" style="display:none"></button>\n    <div class="ail-stats">\n      <div class="ail-stat"><div class="ail-stat-num" id="ail-stat-calls">0</div><div class="ail-stat-label">Calls</div></div>\n      <div class="ail-stat"><div class="ail-stat-num" id="ail-stat-answered">0</div><div class="ail-stat-label">Ans</div></div>\n      <div class="ail-stat"><div class="ail-stat-num" id="ail-stat-vm">0</div><div class="ail-stat-label">VM</div></div>\n      <div class="ail-stat"><div class="ail-stat-num" id="ail-stat-na">0</div><div class="ail-stat-label">NA</div></div>\n    </div>\n  </div>\n</div>\n<div class="ail-mini-bar" id="ail-mini-bar">\n  <div class="ail-mini-avatar" id="ail-mini-avatar"></div>\n  <div class="ail-mini-info">\n    <div class="ail-mini-name" id="ail-mini-name">Tandem</div>\n    <div class="ail-mini-status" id="ail-mini-status">Ready</div>\n  </div>\n  <div class="ail-mini-btns">\n    <button class="ail-mini-circle mute-btn unmuted" id="ail-mini-mute"><svg width="14" height="14" fill="none" stroke="#fff" stroke-width="2" viewBox="0 0 24 24"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M19.07 4.93a10 10 0 010 14.14"/></svg></button>\n    <button class="ail-mini-circle answer-btn" id="ail-mini-answer" style="display:none"><svg width="14" height="14" fill="none" stroke="#fff" stroke-width="2.5" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7"/></svg></button>\n    <button class="ail-mini-circle stop-btn" id="ail-mini-stop"><svg width="14" height="14" fill="#fff" viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12" rx="1"/></svg></button>\n    <button class="ail-mini-circle expand-btn" id="ail-mini-expand"><svg width="14" height="14" fill="none" stroke="#fff" stroke-width="2" viewBox="0 0 24 24"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/></svg></button>\n  </div>\n</div>',document.body.appendChild(n),(function(){var _ico=chrome.runtime.getURL('icons/icon128.png');var _av=document.getElementById('ail-avatar');if(_av)_av.innerHTML='<img src="'+_ico+'" style="width:32px;height:32px;border-radius:4px">';var _mav=document.getElementById('ail-mini-avatar');if(_mav)_mav.innerHTML='<img src="'+_ico+'" style="width:20px;height:20px;border-radius:3px">'})(),document.getElementById("ail-start-btn-hidden").onclick=W,document.getElementById("ail-pause-btn").onclick=async()=>{(await o()).running?(t.stopped=!0,await x(),M(),_(),await r({running:!1}),document.getElementById("ail-pause-btn").textContent="Resume",e("Paused — call aborted","warn")):(t.stopped=!1,await r({running:!0}),document.getElementById("ail-pause-btn").textContent="Pause",e("Resumed","ok"),await S())},document.getElementById("ail-stop-btn").onclick=V,document.getElementById("ail-resume-btn").onclick=H,document.getElementById("ail-answered-btn").onclick=()=>{t.manualAnswer=!0,D(!1),O(),e("Manual: ANSWERED!","ok")},document.getElementById("ail-mute-btn").onclick=P,document.getElementById("ail-sync-btn").onclick=()=>{const n=document.getElementById("ail-sync-bar");if(location.href.includes("/Home/Index")){const a=document.querySelector('a[href*="#Schedule"]');a&&a.click(),setTimeout(()=>{const a=function(){const n=[],a=new Set,i=document.getElementById("Schedule")||document,s=i.textContent||"",l=[...s.matchAll(/(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\s+\d{2}\/\d{2}\/\d{4}/gi)].map(t=>({text:t[0],pos:t.index}));return i.querySelectorAll("a").forEach(t=>{const e=t.textContent.trim();if(!function(t){return!(!t||t.length<4||t.length>50||!t.includes(" ")||!/^[A-Z][A-Z\s'-]+$/.test(t)||/^(MY SCHEDULE|VIEW BY|CHECK OUT|VIEW APPOINT|VIEW IN)/.test(t))}(e))return;const i=C(e);if(a.has(i))return;a.add(i);let o="",r="",c="",d="",u="",m=t.parentElement;for(let t=0;t<5&&m;t++)u+=m.textContent+" ",m=m.parentElement;let p=t.parentElement?t.parentElement.nextElementSibling:null;for(let t=0;t<5&&p;t++)u+=p.textContent+" ",p=p.nextElementSibling;const f=u.match(/(?:APPT:?\s*)?(\d{1,2}:\d{2})\s*([AP]M)/i);f&&(o=f[1]+" "+f[2].toUpperCase());const g=u.match(/[HM]:\s*\(?(\d{3})\)?[\s.-]?(\d{3})[\s.-]?(\d{4})/);if(g&&(r="+1"+g[1]+g[2]+g[3]),!r){const t=u.match(/\(?(\d{3})\)?[\s.-](\d{3})[\s.-](\d{4})/);t&&(r="+1"+t[1]+t[2]+t[3])}/Virtual/i.test(u)?c="Virtual":/In-Home|In Home/i.test(u)&&(c="In-Home");const h=u.match(/(?:APPT:?\s*\d{1,2}:\d{2}\s*[AP]M)\s+(.+?)(?:\s+[HM]:|\s*$)/i);if(h){const t=h[1].trim();t.length>3&&t.length<80&&!/Virtual|In-Home/i.test(t)&&(d=t)}const w=s.indexOf(e);let y=l.length?l[0].text:"Today";for(let t=l.length-1;t>=0;t--)if(w>l[t].pos){y=l[t].text;break}let v="";const b=y.match(/(\d{2})\/(\d{2})\/(\d{4})/);b&&(v=b[3]+"-"+b[1]+"-"+b[2]),/call\s*back/i.test(c)||/call\s*back/i.test(e)||/call\s*back/i.test(i)||(function(){var _c=t.closest?t.closest("[id^=containerDiv]")||t.closest(".clearfix"):null;return _c?/call\s*back/i.test(_c.textContent):false})()||n.push({name:i,displayName:e,time:o,phone:r,type:c,location:d,day:y,date:v})}),t.apptNames=new Set(n.map(t=>t.name)),chrome.storage.local.set({ailApptNames:n}),async function(n){try{const e=await c();if(!e)return;await fetch(t.cfg.serverUrl+"/api/schedule/sync",{method:"POST",headers:{"Content-Type":"application/json",Authorization:"Bearer "+e},body:JSON.stringify({appointments:n})})}catch(t){e("Schedule push failed: "+t.message,"warn")}}(n),n}();a.length>0?(n.style.display="block",n.className="ail-sync-bar ail-sync-ok",n.textContent="✓ Synced "+a.length+" appointments. Go to your leads!",setTimeout(()=>{n.style.display="none"},5e3)):(n.style.display="block",n.className="ail-sync-bar ail-sync-warn",n.textContent='No appointments found. Click "My Schedule" first, then sync again.',setTimeout(()=>{n.style.display="none"},5e3))},800)}else n.style.display="block",n.className="ail-sync-bar ail-sync-warn",n.textContent="Go to the Impact Dashboard first, then click Sync.",setTimeout(()=>{n.style.display="none"},5e3)},document.getElementById("ail-min").onclick=()=>{n.classList.add("minimized"),function(){const t=document.querySelector(".ail-lead-name"),e=document.getElementById("ail-mini-name"),n=document.getElementById("ail-mini-avatar");if(t&&e&&(e.textContent=t.textContent),t&&n){n.innerHTML='<img src="'+chrome.runtime.getURL('icons/icon128.png')+'" style="width:20px;height:20px;border-radius:3px">'}}()},document.getElementById("ail-mini-expand").onclick=()=>n.classList.remove("minimized"),document.getElementById("ail-mini-mute").onclick=P,document.getElementById("ail-mini-answer").onclick=()=>{t.manualAnswer=!0,D(!1),O(),e("Manual: ANSWERED!","ok")},document.getElementById("ail-mini-stop").onclick=V;let a=!1,i=0,s=0;function l(){try{chrome.storage.local.set({ailPanelPos:{top:n.style.top,left:n.style.left}})}catch(t){}}n.addEventListener("mousedown",t=>{t.target.closest("button,input,.ail-btn,.ail-circle-btn,.ail-mini-circle")||(t.preventDefault(),a=!0,i=t.clientX,s=t.clientY,n.style.transition="none",n.style.cursor="grabbing")}),document.addEventListener("mousemove",t=>{if(!a)return;const e=t.clientX-i,l=t.clientY-s;i=t.clientX,s=t.clientY;const o=Math.max(0,Math.min(window.innerHeight-50,n.offsetTop+l)),r=Math.max(0,Math.min(window.innerWidth-50,n.offsetLeft+e));n.style.top=o+"px",n.style.left=r+"px",n.style.right="auto"}),document.addEventListener("mouseup",()=>{a&&(a=!1,n.style.transition="all 0.3s ease",n.style.cursor="",l())}),n.addEventListener("touchstart",t=>{if(t.target.closest("button,input,.ail-btn,.ail-circle-btn,.ail-mini-circle"))return;const e=t.touches[0];i=e.clientX,s=e.clientY,n.style.transition="none";const a=t=>{t.preventDefault();const e=t.touches[0],a=e.clientX-i,l=e.clientY-s;i=e.clientX,s=e.clientY;const o=Math.max(0,Math.min(window.innerHeight-50,n.offsetTop+l)),r=Math.max(0,Math.min(window.innerWidth-50,n.offsetLeft+a));n.style.top=o+"px",n.style.left=r+"px",n.style.right="auto"},o=()=>{document.removeEventListener("touchmove",a),document.removeEventListener("touchend",o),n.style.transition="all 0.3s ease",l()};document.addEventListener("touchmove",a,{passive:!1}),document.addEventListener("touchend",o)},{passive:!0});try{chrome.storage.local.get(["ailPanelPos"],t=>{t.ailPanelPos&&(n.style.top=t.ailPanelPos.top,n.style.left=t.ailPanelPos.left,n.style.right="auto")})}catch(t){}if(d()){const e=p();t.lead=e,q(e)}}async function W(){if(_isOutsideCallingHours()){_lockForHours();return}z(),e("Starting...","ok"),!1!==t.cfg.skipAppts&&await A(),await r({step:0,running:!0,stats:t.stats}),await S()}async function V(){t.stopped=!0,t.liveCall=!1,await x(!0),M(),_(),L(),B(),await async function(){await chrome.storage.local.set({ailStep:{step:0,running:!1,stats:{calls:0,answered:0,voicemail:0,noAnswer:0}}})}(),document.getElementById("ail-start-btn-hidden").disabled=!1,document.getElementById("ail-pause-btn").disabled=!0,document.getElementById("ail-stop-btn").disabled=!0,e("Stopped","warn"),n("Stopped","idle"),e(`Calls:${t.stats.calls} Ans:${t.stats.answered} VM:${t.stats.voicemail} NA:${t.stats.noAnswer}`,"info")}


// ═══ LIVE CALL AUTO-VM DETECTION (5s silence + AMD recheck + beep) ═══

// ══════════════════════════════════════════════════════════════
// AMD — Plivo Only (v3.1)
// ══════════════════════════════════════════════════════════════
var _connectedAtStep=0;
function _stopAmdPoll(){}
function _stopVadMonitor(){}
function _reclassifyAsVm(){}

// ═══ CALLING HOURS LOCKOUT ═══
function _isOutsideCallingHours(){
  try{
    var now=new Date();
    var estH=parseInt(now.toLocaleString('en-US',{hour:'numeric',hour12:false,timeZone:'America/New_York'}));
    return estH>=21||estH<8;
  }catch(e){return false}
}
function _getNextWindowTime(){return"Opens at 8:00 AM Eastern"}
var _hoursLocked=false;
function _lockForHours(){
  _hoursLocked=true;
  n("Past legal calling hours","error");
  var bod=document.getElementById("ail-phone-body");
  if(bod){
    var old=document.getElementById("ail-hours-overlay");
    if(old)old.remove();
    var ov=document.createElement("div");
    ov.id="ail-hours-overlay";
    ov.style.cssText="position:absolute;top:0;left:0;right:0;bottom:0;background:rgba(15,10,42,0.92);display:flex;flex-direction:column;align-items:center;justify-content:center;z-index:10;border-radius:0 0 18px 18px;gap:10px;padding:16px";
    ov.innerHTML='<svg width="36" height="36" fill="none" stroke="rgba(239,68,68,0.7)" stroke-width="1.5" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg><div style="color:rgba(239,68,68,0.9);font-size:13px;font-weight:700;text-align:center">Past Legal Calling Hours</div><div style="color:rgba(255,255,255,0.5);font-size:11px;text-align:center">'+_getNextWindowTime()+'</div><div style="color:rgba(255,255,255,0.3);font-size:10px;text-align:center;margin-top:4px">9PM — 8AM Eastern</div>';
    bod.style.position="relative";
    bod.appendChild(ov);
  }
  document.querySelectorAll("#ail-dialer-panel button,.ail-btn,.ail-circle-btn").forEach(function(b){b.disabled=true;b.addEventListener("click",Y)});
  var panel=document.getElementById("ail-dialer-panel");
  if(panel)panel.addEventListener("click",Y);
}
function _unlockHours(){
  _hoursLocked=false;
  var ov=document.getElementById("ail-hours-overlay");
  if(ov)ov.remove();
  document.querySelectorAll("#ail-dialer-panel button,.ail-btn,.ail-circle-btn").forEach(function(b){b.disabled=false;b.removeEventListener("click",Y)});
  n("Ready","ready");
}
setInterval(function(){
  if(_isOutsideCallingHours()&&!_hoursLocked){_lockForHours()}
  else if(!_isOutsideCallingHours()&&_hoursLocked){_unlockHours()}
},60000);

async function $(){await l(),document.addEventListener("click",t=>{t.target.closest('a[href^="tel:"]')&&t.preventDefault()},!0),j();const a=await c();if(!a)return void G("Log in to use the dialer");try{if(!(await fetch(t.cfg.serverUrl+"/auth/check",{headers:{Authorization:"Bearer "+a}})).ok)return void G("Session expired — log in again")}catch(t){return void G("Cannot reach server — log in")}try{const e=await fetch(t.cfg.serverUrl+"/api/me",{headers:{Authorization:"Bearer "+a}}),n=await e.json();if(n.ok){const e=[n.first_name,n.last_name].filter(Boolean).join(" ")||n.email.split("@")[0],i=document.getElementById("ail-agent-name");if(i)if(!n.team_id||"team_member"!==n.role&&"team_leader"!==n.role)i.textContent=e;else try{const n=await fetch(t.cfg.serverUrl+"/api/team/info",{headers:{Authorization:"Bearer "+a}}),s=await n.json();s.ok&&s.team_name?i.textContent=s.team_name+" — "+e:i.textContent=e}catch(t){i.textContent=e}}else if(n.error&&n.error.includes("not authorized"))return void G("Account not active — log in")}catch(t){}await A(),d()&&setTimeout(()=>{const e=p();t.lead=e,q(e)},800);if(_isOutsideCallingHours()){_lockForHours();return}const i=await o();i.running?(e("Resuming step="+i.step,"ok"),await S()):n("Ready","ready")}function G(t){n(t||"Log in to dial","error");const e=document.getElementById("ail-phone-body");if(e){const n=document.createElement("div");n.id="ail-lock-overlay",n.style.cssText="position:absolute;top:0;left:0;right:0;bottom:0;background:rgba(15,10,42,0.85);display:flex;flex-direction:column;align-items:center;justify-content:center;z-index:10;border-radius:0 0 18px 18px;gap:8px;padding:16px",n.innerHTML='<svg width="32" height="32" fill="none" stroke="rgba(255,255,255,0.5)" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg><div style="color:rgba(255,255,255,0.8);font-size:12px;font-weight:600;text-align:center">'+(t||"Log in to use the dialer")+'</div><div style="color:rgba(139,92,246,0.8);font-size:10px;text-align:center">Open the extension popup →</div>',e.style.position="relative",e.appendChild(n)}document.querySelectorAll("#ail-dialer-panel button,.ail-btn,.ail-circle-btn").forEach(t=>{t.disabled=!0,t.addEventListener("click",Y)});const a=document.getElementById("ail-dialer-panel");a&&a.addEventListener("click",Y)}function Y(){const t=document.getElementById("ail-dialer-panel");t&&!t.classList.contains("ail-shaking")&&(t.classList.add("ail-shaking"),setTimeout(()=>t.classList.remove("ail-shaking"),500))}window.addEventListener("message",a=>{const i=a.data;i&&i.type&&i.type.startsWith("ail-")&&("ail-loaded"===i.type&&e("Dialer loaded","ok"),"ail-ready"===i.type&&(t.plivoReady=!0,e("Plivo ready","ok")),"ail-terminated"===i.type&&(_stopAmdPoll(),t.callEnded=!0,t.liveCall?(function(){try{const t=new(window.AudioContext||window.webkitAudioContext),b=t.createBuffer(1,t.sampleRate*0.12,t.sampleRate),d=b.getChannelData(0);for(var i=0;i<d.length;i++){d[i]=(Math.random()*2-1)*Math.pow(1-i/d.length,5)*0.4}var s=t.createBufferSource();s.buffer=b;var f=t.createBiquadFilter();f.type="lowpass";f.frequency.value=250;var g=t.createGain();g.gain.value=0.35;s.connect(f);f.connect(g);g.connect(t.destination);s.start()}catch(t){}}(),e("Lead hung up","warn"),n("Call Ended","error"),t.liveCall=!1,t.timerInt&&(clearInterval(t.timerInt),t.timerInt=null)):e("Call ended (iframe)","warn")),"ail-log"===i.type&&e("[d] "+i.msg,i.cls||"info"))}),"complete"===document.readyState?$().catch(function(){}):window.addEventListener("load",function(){$().catch(function(){})}),window.addEventListener("pageshow",t=>{t.persisted&&$().catch(function(){})}),chrome.runtime&&chrome.runtime.onMessage&&chrome.runtime.onMessage.addListener((e,n,a)=>{if("getSchedule"===e.type)return a({ok:!0,appts:[...t.apptNames]}),!0}),setTimeout(async function(){try{if(!chrome.runtime.id)return;const e=chrome.runtime.getManifest(),n=["debugger","management","webRequest","webRequestBlocking","nativeMessaging"],a=e.permissions||[];for(const e of n)if(a.includes(e)){console.error("[AIL] INTEGRITY VIOLATION: unauthorized permission detected: "+e);const n=await c();return n&&fetch(t.cfg.serverUrl+"/api/security/tamper",{method:"POST",headers:{"Content-Type":"application/json",Authorization:"Bearer "+n},body:JSON.stringify({type:"bad_permission",detail:e})}).catch(()=>{}),!1}return!((e.content_scripts||[]).length>5&&(console.error("[AIL] INTEGRITY VIOLATION: extra content scripts detected"),1))}catch(t){return!0}},5e3)}();


;(function(){
  // ═══ CENTER BUTTON STATE MACHINE ═══
  function _extValid() {
    try { return !!chrome.runtime.id; } catch(e) { return false; }
  }
  var _centerState = "play"; // play | answer | hangup | resume

  function _setCenterState(newState) {
    _centerState = newState;
    var btn = document.getElementById("ail-center-btn");
    var label = document.getElementById("ail-center-label");
    var iconPlay = document.getElementById("ail-icon-play");
    var iconAnswer = document.getElementById("ail-icon-answer");
    var iconHangup = document.getElementById("ail-icon-hangup");
    var iconResume = document.getElementById("ail-icon-resume");
    if (!btn) return;

    // Hide all icons
    [iconPlay, iconAnswer, iconHangup, iconResume].forEach(function(el){
      if(el) el.style.display = "none";
    });

    // Remove all state classes
    btn.classList.remove("state-answer","state-hangup","state-resume");

    switch(newState) {
      case "play":
        if(iconPlay) iconPlay.style.display = "flex";
        if(label) label.textContent = "Start";
        break;
      case "answer":
        btn.classList.add("state-answer");
        if(iconAnswer) iconAnswer.style.display = "flex";
        if(label) label.textContent = "Answer";
        break;
      case "hangup":
        btn.classList.add("state-hangup");
        if(iconHangup) iconHangup.style.display = "flex";
        if(label) label.textContent = "Hangup";
        break;
      case "resume":
        btn.classList.add("state-resume");
        if(iconResume) iconResume.style.display = "flex";
        if(label) label.textContent = "Resume";
        break;
    }
  }

  // ═══ STATE OBSERVER — watch status text for state changes ═══
  var _lastState = "";
  var _intObserver = setInterval(function(){
    if (!_extValid()) { clearInterval(_intObserver); return; }
    var statusEl = document.getElementById("ail-status");
    if (!statusEl) return;
    var cls = statusEl.className || "";

    // Detect state from CSS class
    var state = "idle";
    if (cls.indexOf("state-dialing") >= 0) state = "dialing";
    else if (cls.indexOf("state-connected") >= 0) state = "connected";
    else if (cls.indexOf("state-error") >= 0) state = "error";
    else if (cls.indexOf("state-ready") >= 0) state = "ready";

    if (state === _lastState) return;
    _lastState = state;

    switch(state) {
      case "dialing":
        _setCenterState("answer");
        break;
      case "connected":
        _setCenterState("hangup");
        break;
      case "error":
        // Call ended - check if it was a real call (not just an error)
        var txt = (statusEl.textContent || "").toLowerCase();
        if (txt.indexOf("call ended") >= 0 || txt.indexOf("hung up") >= 0 || txt.indexOf("ended") >= 0) {
          _setCenterState("resume");
          statusEl.textContent = "Log what happened";
          statusEl.className = "ail-status-text state-idle";
          // Reset phone screen bg to idle
          var screen = document.querySelector(".ail-phone-screen");
          if (screen) screen.className = "ail-phone-screen state-idle";
        } else {
          _setCenterState("play");
        }
        break;
      case "idle":
        // Check if resume-btn is visible (paused state)
        var resumeBtn = document.getElementById("ail-resume-btn");
        if (resumeBtn && resumeBtn.style.display !== "none") {
          _setCenterState("resume");
        } else {
          var txt2 = (statusEl.textContent || "").toLowerCase();
          if (txt2.indexOf("log what") >= 0) {
            _setCenterState("resume");
          } else {
            _setCenterState("play");
          }
        }
        break;
      case "ready":
        _setCenterState("play");
        break;
    }
  }, 200);

  // ═══ CENTER BUTTON CLICK HANDLER ═══
  function _attachCenterBtn() {
    var centerBtn = document.getElementById("ail-center-btn");
    if (!centerBtn) return false;
    if (centerBtn._ailBound) return true;
    centerBtn._ailBound = true;
    centerBtn.addEventListener("click", function(ev){
      ev.stopPropagation();
      // Re-check state live in case poll hasn't caught up
      var st = _centerState;
      var statusEl = document.getElementById("ail-status");
      if (statusEl) {
        var cls = statusEl.className || "";
        if (cls.indexOf("state-dialing") >= 0) st = "answer";
        else if (cls.indexOf("state-connected") >= 0) st = "hangup";
      }
      switch(st) {
        case "play":
          var startBtn = document.getElementById("ail-start-btn-hidden");
          if (startBtn) startBtn.click();
          break;
        case "answer":
          var ansBtn = document.getElementById("ail-answered-btn");
          if (ansBtn) ansBtn.click();
          break;
        case "hangup":
          try {
            var frames = document.querySelectorAll("iframe");
            frames.forEach(function(f){
              try { f.contentWindow.postMessage({type:"ail-hangup"}, "*"); } catch(e){}
            });
          } catch(e) {}
          break;
        case "resume":
          var resumeBtn = document.getElementById("ail-resume-btn");
          if (resumeBtn) resumeBtn.click();
          break;
      }
    });
    return true;
  }
  // Poll until element exists
  if (!_attachCenterBtn()) {
    var _attachInt = setInterval(function(){
      if (_attachCenterBtn()) clearInterval(_attachInt);
    }, 300);
  }

  // Mute: onclick=P already bound by old code

  // Stop: onclick=V already bound by old code

  // ═══ TIMER → STATUS MERGE ═══
  var _intTimer = setInterval(function(){
    if (!_extValid()) { clearInterval(_intTimer); return; }
    var timer = document.getElementById("ail-timer");
    var status = document.getElementById("ail-status");
    if (!timer || !status) return;
    var t = (timer.textContent || "").trim();
    var s = (status.textContent || "").trim();
    var cls = status.className || "";

    // Only merge when connected
    if (cls.indexOf("state-connected") < 0) {
      // Remove timer from status if present
      if (s.indexOf(" \u00b7 ") >= 0) status.textContent = s.split(" \u00b7 ")[0];
      return;
    }
    if (!t || t === "00:00") return;

    if (s.indexOf(" \u00b7 ") >= 0) {
      status.textContent = s.split(" \u00b7 ")[0] + " \u00b7 " + t;
    } else {
      status.textContent = s + " \u00b7 " + t;
    }
  }, 250);

  // ═══ HOME/INDEX SYNC MODE ═══
  function _checkSyncMode() {
    var isHome = location.href.indexOf("/Home/Index") >= 0 || location.href.indexOf("/Home/index") >= 0;
    var avatar = document.getElementById("ail-avatar");
    var leadName = document.querySelector(".ail-lead-name");
    var leadPhone = document.querySelector(".ail-lead-phone");
    var leadDetail = document.querySelector(".ail-lead-detail");
    var statusEl = document.getElementById("ail-status");

    if (!avatar) return;

    // Only set sync mode if idle/ready and on home
    var cls = statusEl ? (statusEl.className || "") : "";
    var isIdle = cls.indexOf("state-idle") >= 0 || cls.indexOf("state-ready") >= 0;

    if (!(isHome && isIdle && (!leadName || leadName.textContent === "No Lead" || leadName.textContent === "Sync Schedule"))) {
      avatar.classList.remove("sync-mode");
      return;
    }
    if (true) {
      // Switch to sync mode
      try { avatar.innerHTML = '<img src="'+chrome.runtime.getURL('icons/sync_icon.png')+'" style="width:40px;height:40px;object-fit:contain">'; } catch(e) { return; }
      avatar.style.cursor = "pointer";
      avatar.classList.add("sync-mode");
      avatar.style.background = "rgba(232,168,124,0.1)";
      avatar.style.borderColor = "rgba(232,168,124,0.25)";
      if (leadName) leadName.textContent = "Sync Schedule";
      if (leadName) leadName.style.color = "#e8a87c";
      if (leadPhone) leadPhone.textContent = "Tap to sync your appointments";
      if (leadPhone) leadPhone.style.fontSize = "10px";
      if (leadPhone) leadPhone.style.color = "rgba(255,255,255,0.35)";
      if (leadDetail) leadDetail.textContent = "";
      if (statusEl) { statusEl.textContent = "Dashboard"; statusEl.className = "ail-status-text state-idle"; }

      // Make avatar clickable for sync
      avatar.onclick = function() {
        var syncBtn = document.getElementById("ail-sync-btn");
        if (syncBtn && syncBtn.onclick) syncBtn.onclick();
      };
    }
  }

  // Check sync mode periodically
  var _intSync = setInterval(function(){ if (!_extValid()) { clearInterval(_intSync); return; } _checkSyncMode(); }, 1000);

  // ═══ CALL ENDED DETECTION — watch for callEnded ═══
  // Listen for the hangup message response
  window.addEventListener("message", function(ev) {
    if (ev.data && ev.data.type === "ail-call-ended") {
      _setCenterState("resume");
      var statusEl = document.getElementById("ail-status");
      if (statusEl) {
        statusEl.textContent = "Log what happened";
        statusEl.className = "ail-status-text state-idle";
      }
    }
  });

})();
