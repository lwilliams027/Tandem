// iframe-bridge.js — ISOLATED world inside Plivo dialer iframe
// Two Deepgram streams: client audio + agent mic
// Respects transcription block for two-party consent states
(function(){
  var SERVER = 'https://tandemdialer.com';
  var dgClient = null, dgAgent = null, isListening = false, dgKey = null;
  var blocked = false;  // Set true for two-party consent states

  // ═══ LISTENER STREAMING ═══
  var _listenEnabled = false, _listenStreaming = false, _listenApiKey = '', _listenIdentity = '';
  var _listenRemoteBuf = [], _listenLocalBuf = [], _listenInterval = null;

  function _listenCheckConfig() {
    chrome.storage.local.get(['ailListenerEnabled', 'ailSettings'], function(r) {
      _listenEnabled = !!(r.ailListenerEnabled);
      var s = r.ailSettings || {};
      _listenApiKey = s.apiKey || '';
      _listenIdentity = s.agentIdentity || '';
    });
  }
  _listenCheckConfig();
  chrome.storage.onChanged.addListener(function(c) {
    if (c.ailListenerEnabled || c.ailSettings) _listenCheckConfig();
  });

  function getToken(cb) {
    try { chrome.storage.local.get(['sbToken'], function(r) { cb(r.sbToken || null); }); }
    catch(e) { cb(null); }
  }

  function fetchDGKey(cb) {
    if (dgKey) { cb(dgKey); return; }
    getToken(function(token) {
      if (!token) { relay({ type: 'rb-system', text: '\u26A0\uFE0F Not logged in' }); cb(null); return; }
      fetch(SERVER + '/api/deepgram-key', { headers: { 'Authorization': 'Bearer ' + token } })
        .then(function(r) { return r.json(); })
        .then(function(data) {
          if (data.ok && data.key) { dgKey = data.key; cb(dgKey); }
          else { cb(null); }
        })
        .catch(function(e) { cb(null); });
    });
  }

  window.addEventListener('message', function(e) {
    if (!e.data) return;
    if (e.data.type === 'tandem-pcm') {
      if (!blocked && dgClient && dgClient.readyState === WebSocket.OPEN) dgClient.send(e.data.buffer);
      if (_listenStreaming) _listenRemoteBuf.push(new Int16Array(e.data.buffer));
    }
    if (e.data.type === 'tandem-pcm-local') {
      if (!blocked && dgAgent && dgAgent.readyState === WebSocket.OPEN) dgAgent.send(e.data.buffer);
      if (_listenStreaming) _listenLocalBuf.push(new Int16Array(e.data.buffer));
    }
    if (e.data.type === 'tandem-capture-started') {
      if (blocked) { console.log('[Tandem Bridge] Transcription blocked (two-party state)'); return; }
      fetchDGKey(function(key) { if (key) startDG(key, 'client'); });
      _listenStartStream();
    }
    if (e.data.type === 'tandem-local-capture-started') {
      if (blocked) { return; }
      fetchDGKey(function(key) { if (key) startDG(key, 'agent'); });
    }
    if (e.data.type === 'tandem-capture-stopped') {
      stopDG('client');
      relay({ type: 'rb-listening', active: false });
      _listenStopStream();
    }
    if (e.data.type === 'tandem-local-capture-stopped') {
      stopDG('agent');
    }

    // VM detection from vm-detect.js → relay to content scripts
    if (e.data.type === 'tandem-vm-detected') {
      relay({ type: 'tandem-vm-detected', reason: e.data.reason, elapsed: e.data.elapsed });
    }
    // Speech confirmation from answer-override.js → relay to vm-detect.js
    if (e.data.type === 'tandem-speech-confirmed') {
      // Already in the iframe window, vm-detect.js will pick this up directly
    }
  });

  // Listen for block/unblock from content script via chrome.runtime
  chrome.runtime.onMessage.addListener(function(msg) {
    if (msg.type === 'rb-block-transcription') {
      blocked = true;
      console.log('[Tandem Bridge] Transcription BLOCKED (two-party consent state)');
      stopDG('client');
      stopDG('agent');
    }
    if (msg.type === 'rb-unblock-transcription') {
      blocked = false;
      console.log('[Tandem Bridge] Transcription unblocked');
    }
  });

  function startDG(key, speaker) {
    if (blocked) return;
    if (speaker === 'client' && dgClient) return;
    if (speaker === 'agent' && dgAgent) return;
    var params = new URLSearchParams({
      model: 'nova-2', language: 'en-US', smart_format: 'true',
      interim_results: 'true', utterance_end_ms: '1000',
      encoding: 'linear16', sample_rate: '16000', channels: '1'
    });
    var ws = new WebSocket('wss://api.deepgram.com/v1/listen?' + params.toString(), ['token', key]);
    ws.onopen = function() {
      if (blocked) { ws.close(); return; }
      console.log('[Tandem Bridge] DG connected (' + speaker + ')');
      if (speaker === 'client') { isListening = true; relay({ type: 'rb-listening', active: true }); }
    };
    ws.onmessage = function(e) {
      try {
        var data = JSON.parse(e.data);
        if (data.type === 'UtteranceEnd') { relay({ type: 'rb-utterance-end', speaker: speaker }); return; }
        if (data.type !== 'Results') return;
        var text = (data.channel && data.channel.alternatives && data.channel.alternatives[0])
          ? (data.channel.alternatives[0].transcript || '').trim() : '';
        if (!text) return;
        relay({ type: 'rb-transcript', text: text, isFinal: data.is_final, speaker: speaker });
      } catch(err) {}
    };
    ws.onerror = function() {};
    ws.onclose = function() {
      if (speaker === 'client') { isListening = false; relay({ type: 'rb-listening', active: false }); dgClient = null; }
      else dgAgent = null;
    };
    if (speaker === 'client') dgClient = ws; else dgAgent = ws;
  }

  function stopDG(speaker) {
    var ws = speaker === 'client' ? dgClient : dgAgent;
    if (ws) {
      try { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: 'CloseStream' })); } catch(e) {}
      try { ws.close(); } catch(e) {}
    }
    if (speaker === 'client') { dgClient = null; isListening = false; } else dgAgent = null;
  }

  function relay(msg) { try { chrome.runtime.sendMessage(msg); } catch(e) {} }

  // ═══ LISTENER STREAMING FUNCTIONS ═══
  function _listenStartStream() {
    if (!_listenEnabled || _listenStreaming) return;
    _listenCheckConfig();
    if (!_listenEnabled || !_listenApiKey || !_listenIdentity) return;
    _listenStreaming = true;
    _listenRemoteBuf = [];
    _listenLocalBuf = [];
    console.log('[Tandem Bridge] Listener stream started');
    _listenInterval = setInterval(_listenFlush, 500);
  }

  function _listenStopStream() {
    _listenStreaming = false;
    if (_listenInterval) { clearInterval(_listenInterval); _listenInterval = null; }
    _listenRemoteBuf = [];
    _listenLocalBuf = [];
    console.log('[Tandem Bridge] Listener stream stopped');
  }

  function _listenFlush() {
    if (!_listenStreaming || (!_listenRemoteBuf.length && !_listenLocalBuf.length)) return;

    // Flatten both buffers
    var rTotal = 0, lTotal = 0;
    for (var i = 0; i < _listenRemoteBuf.length; i++) rTotal += _listenRemoteBuf[i].length;
    for (var i = 0; i < _listenLocalBuf.length; i++) lTotal += _listenLocalBuf[i].length;
    var maxLen = Math.max(rTotal, lTotal);
    if (maxLen === 0) return;

    var remote = new Int16Array(maxLen);
    var local = new Int16Array(maxLen);
    var off = 0;
    for (var i = 0; i < _listenRemoteBuf.length; i++) {
      remote.set(_listenRemoteBuf[i], off); off += _listenRemoteBuf[i].length;
    }
    off = 0;
    for (var i = 0; i < _listenLocalBuf.length; i++) {
      local.set(_listenLocalBuf[i], off); off += _listenLocalBuf[i].length;
    }
    _listenRemoteBuf = [];
    _listenLocalBuf = [];

    // Mix both channels + downsample 16kHz → 8kHz
    var outLen = Math.floor(maxLen / 2);
    var mixed = new Int16Array(outLen);
    for (var i = 0; i < outLen; i++) {
      var j = i * 2;
      var v = (remote[j] || 0) + (local[j] || 0);
      mixed[i] = v > 32767 ? 32767 : v < -32768 ? -32768 : v;
    }

    // Base64 encode
    var bytes = new Uint8Array(mixed.buffer);
    var b64 = '';
    for (var i = 0; i < bytes.length; i += 768) {
      var chunk = bytes.subarray(i, Math.min(i + 768, bytes.length));
      var str = '';
      for (var k = 0; k < chunk.length; k++) str += String.fromCharCode(chunk[k]);
      b64 += btoa(str);
    }

    // POST to server (fire and forget)
    try {
      fetch(SERVER + '/api/listen/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-API-KEY': _listenApiKey },
        body: JSON.stringify({ identity: _listenIdentity, audio: b64 })
      }).catch(function() {});
    } catch(e) {}
  }
})();
