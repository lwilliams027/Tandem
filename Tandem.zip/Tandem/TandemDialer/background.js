const SERVER="https://tandemdialer.com";let _signupPollTimer=null;chrome.runtime.onMessage.addListener((e,t,o)=>{if("getToken"===e.type)return chrome.storage.local.get(["sbToken"],e=>{o({token:e.sbToken||null})}),!0;if("getSettings"===e.type)return chrome.storage.local.get(["ailSettings"],e=>{o({settings:e.ailSettings||{}})}),!0;if("refreshToken"===e.type)return chrome.storage.local.get(["ailSettings"],async e=>{const t=e.ailSettings||{};if(t.supabaseEmail&&t.supabasePassword&&t.serverUrl)try{const e=await fetch(`${t.serverUrl}/auth/login`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email:t.supabaseEmail,password:t.supabasePassword})}),s=await e.json();s.ok&&s.access_token?(await chrome.storage.local.set({sbToken:s.access_token}),o({ok:!0})):o({ok:!1})}catch(e){o({ok:!1})}else o({ok:!1})}),!0;if("startSignupPoll"===e.type){const{ref:t,email:s,password:l}=e;_signupPollTimer&&clearInterval(_signupPollTimer);let a=0;return chrome.storage.local.set({signupPoll:{ref:t,email:s,password:l,status:"polling"}}),_signupPollTimer=setInterval(async()=>{if(a++,a>120)return clearInterval(_signupPollTimer),_signupPollTimer=null,void chrome.storage.local.set({signupPoll:{ref:t,email:s,password:l,status:"timeout"}});try{const e=await fetch(SERVER+"/api/signup-status/"+t),o=await e.json();if(o.ok&&"complete"===o.status){clearInterval(_signupPollTimer),_signupPollTimer=null;try{const e=await fetch(SERVER+"/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email:s,password:l})}),o=await e.json();if(o.ok&&o.access_token){await chrome.storage.local.set({sbToken:o.access_token});const e="ail_d1al3r_"+chrome.runtime.id;let a=btoa(unescape(encodeURIComponent(l))),r="";for(let t=0;t<a.length;t++)r+=String.fromCharCode(a.charCodeAt(t)^e.charCodeAt(t%e.length));const i=btoa(r);await chrome.storage.local.set({ailSettings:{serverUrl:SERVER,supabaseEmail:s,supabasePassword:i,agentIdentity:o.identity||"",doubleTap:!0,autoMute:!0,skipAppts:!0,apiKey:o.api_key||""}}),await chrome.storage.local.set({signupPoll:{ref:t,status:"logged_in"}})}else await chrome.storage.local.set({signupPoll:{ref:t,email:s,password:l,status:"complete_no_login"}})}catch(e){await chrome.storage.local.set({signupPoll:{ref:t,email:s,password:l,status:"complete_no_login"}})}}else"failed"===o.status&&(clearInterval(_signupPollTimer),_signupPollTimer=null,chrome.storage.local.set({signupPoll:{ref:t,status:"failed",error:o.error||""}}))}catch(e){}},3e3),o({ok:!0}),!0}if("stopSignupPoll"===e.type)return _signupPollTimer&&(clearInterval(_signupPollTimer),_signupPollTimer=null),chrome.storage.local.remove(["signupPoll"]),o({ok:!0}),!0;if("getSignupPollStatus"===e.type)return chrome.storage.local.get(["signupPoll"],e=>{o(e.signupPoll||null)}),!0;if("clickInPage"===e.type){const s=t.tab?.id;return s?(chrome.scripting.executeScript({target:{tabId:s},world:"MAIN",func:e=>{const t=document.querySelector(e);if(t)return t.click(),{ok:!0,clicked:e};const o=document.getElementById(e.replace("#",""));return o?(o.click(),{ok:!0,clicked:e}):{ok:!1,error:"Element not found: "+e}},args:[e.selector]}).then(e=>{o(e?.[0]?.result||{ok:!1})}).catch(e=>{o({ok:!1,error:e.message})}),!0):(o({ok:!1}),!0)}});

// ═══ REBUTTAL COACH ═══
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'rebuttalQuery') {
    chrome.storage.local.get(['sbToken'], (r) => {
      const token = r.sbToken || '';
      fetch(SERVER + '/api/rebuttal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
        body: JSON.stringify(msg.payload)
      })
      .then(r => r.json())
      .then(data => sendResponse(data))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    });
    return true;
  }

  // ═══ SAVE CALL TRANSCRIPT ═══
  if (msg.type === 'saveCallTranscript') {
    chrome.storage.local.get(['sbToken'], (r) => {
      const token = r.sbToken || '';
      fetch(SERVER + '/api/call-transcript', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
        body: JSON.stringify(msg.payload)
      })
      .then(r => r.json())
      .then(data => sendResponse(data))
      .catch(err => sendResponse({ ok: false }));
    });
    return true;
  }

  // ═══ ADD TO DNC — sends number to server's internal DNC list ═══
  if (msg.type === 'addToDNC') {
    chrome.storage.local.get(['sbToken'], (r) => {
      const token = r.sbToken || '';
      fetch(SERVER + '/api/dnc/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
        body: JSON.stringify(msg.payload)
      })
      .then(r => r.json())
      .then(data => {
        console.log('[Tandem] DNC added:', data);
        sendResponse(data);
      })
      .catch(err => {
        console.log('[Tandem] DNC add failed:', err.message);
        sendResponse({ ok: false });
      });
    });
    return true;
  }

  // ═══ BLOCK/UNBLOCK TRANSCRIPTION ═══
  if (msg.type === 'rb-block-transcription' || msg.type === 'rb-unblock-transcription') {
    const tabId = sender.tab?.id;
    if (tabId) chrome.tabs.sendMessage(tabId, msg).catch(() => {});
  }

  // ═══ TRANSCRIPT RELAY ═══
  if (msg.type === 'rb-transcript' || msg.type === 'rb-system' || msg.type === 'rb-listening' || msg.type === 'rb-utterance-end') {
    const tabId = sender.tab?.id;
    if (tabId) chrome.tabs.sendMessage(tabId, msg).catch(() => {});
  }
});

// ═══ AUTO-UPDATE CHECKER ═══
const UPDATE_CHECK_INTERVAL = 60 * 60 * 1000;
async function checkForUpdate() {
  try {
    const manifest = chrome.runtime.getManifest();
    const r = await fetch(SERVER + "/api/extension/version");
    const data = await r.json();
    if (data.version && data.version !== manifest.version) {
      await chrome.storage.local.set({ updateAvailable: { current: manifest.version, latest: data.version, download_url: data.download_url || "", changelog: data.changelog || "", checked_at: Date.now() } });
      chrome.action.setBadgeText({ text: "!" });
      chrome.action.setBadgeBackgroundColor({ color: "#ef4444" });
    } else {
      await chrome.storage.local.remove(["updateAvailable"]);
      chrome.action.setBadgeText({ text: "" });
    }
  } catch (e) {}
}
checkForUpdate();
setInterval(checkForUpdate, UPDATE_CHECK_INTERVAL);
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "checkUpdate") {
    checkForUpdate().then(() => { chrome.storage.local.get(["updateAvailable"], (r) => { sendResponse(r.updateAvailable || null); }); });
    return true;
  }
});
