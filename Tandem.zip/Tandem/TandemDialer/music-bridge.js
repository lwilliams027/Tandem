// ═══════════════════════════════════════════════════════
// music-bridge.js — Observes call state, injects YouTube player
// Replaces spotify-bridge.js — no OAuth, no API keys, no user limits
// ═══════════════════════════════════════════════════════

(function() {
  'use strict';

  let _initialized = false;
  let _lastState = '';
  let _wasOnCall = false;

  // ─── Wait for overlay panel to exist ───
  function waitForPanel() {
    return new Promise(resolve => {
      const check = () => {
        const panel = document.getElementById('ail-dialer-panel');
        if (panel) return resolve(panel);
        setTimeout(check, 500);
      };
      check();
    });
  }

  // ─── Inject player container into overlay ───
  function injectContainer(panel) {
    if (document.getElementById('ail-music-bar')) return null;

    const container = document.createElement('div');
    container.id = 'ail-music-bar';

    // Insert into the phone-bottom area, before the stats
    const phoneBottom = panel.querySelector('.ail-phone-bottom');
    const stats = panel.querySelector('.ail-stats');
    if (phoneBottom && stats) {
      phoneBottom.insertBefore(container, stats);
    } else {
      const body = panel.querySelector('.ail-phone-body');
      if (body) body.appendChild(container);
    }

    return container;
  }

  // ─── Detect call state from overlay DOM ───
  function getCurrentState() {
    const statusEl = document.getElementById('ail-status');
    if (!statusEl) return 'unknown';
    const text = statusEl.textContent.toLowerCase().trim();
    if (text.includes('connected')) return 'connected';
    if (text.includes('ringing')) return 'ringing';
    if (text.includes('dialing')) return 'dialing';
    if (text.includes('call ended')) return 'ended';
    if (text.includes('ready')) return 'ready';
    if (text.includes('stopped')) return 'stopped';
    return 'other';
  }

  // ─── Observe state changes ───
  function observeCallState() {
    const statusEl = document.getElementById('ail-status');
    if (!statusEl) return;

    const observer = new MutationObserver(() => {
      const newState = getCurrentState();
      if (newState === _lastState) return;

      const prevState = _lastState;
      _lastState = newState;

      // CONNECTED → pause music
      if (newState === 'connected' && !_wasOnCall) {
        _wasOnCall = true;
        console.log('[Music Bridge] Call connected — pausing music');
        if (typeof YouTubePlayer !== 'undefined') {
          YouTubePlayer.onCallAnswered();
        }
      }

      // Call ended (was on call) → resume music
      if (_wasOnCall && (newState === 'ready' || newState === 'stopped' || newState === 'ended' || newState === 'other')) {
        setTimeout(() => {
          const confirmState = getCurrentState();
          if (confirmState !== 'connected' && confirmState !== 'ringing' && confirmState !== 'dialing') {
            _wasOnCall = false;
            console.log('[Music Bridge] Call ended — resuming music');
            if (typeof YouTubePlayer !== 'undefined') {
              YouTubePlayer.onCallEnded();
            }
          }
        }, 500);
      }
    });

    observer.observe(statusEl, { childList: true, characterData: true, subtree: true });

    // Also listen for window messages
    window.addEventListener('message', e => {
      if (!e.data || !e.data.type) return;
      if (e.data.type === 'ail-terminated' && _wasOnCall) {
        setTimeout(() => {
          _wasOnCall = false;
          console.log('[Music Bridge] Call terminated — resuming music');
          if (typeof YouTubePlayer !== 'undefined') {
            YouTubePlayer.onCallEnded();
          }
        }, 500);
      }
    });
  }

  // ─── Main ───
  async function init() {
    if (_initialized) return;
    _initialized = true;

    const panel = await waitForPanel();
    console.log('[Music Bridge] Panel found, injecting music player');

    const container = injectContainer(panel);
    if (!container) {
      console.warn('[Music Bridge] Could not inject container');
      return;
    }

    // Check if user has music access
    var hasAccess = false;
    try {
      var result = await new Promise(function(resolve) {
        chrome.storage.local.get(['ailMusicAccess'], function(r) { resolve(r.ailMusicAccess || false); });
      });
      hasAccess = result;
    } catch(e) {}

    if (!hasAccess) {
      console.log('[Music Bridge] No music access — player hidden');
      // Re-check periodically in case user purchases addon mid-session
      setInterval(function() {
        chrome.storage.local.get(['ailMusicAccess'], function(r) {
          if (r.ailMusicAccess && !_initialized) {
            _initialized = false;
            init();
          }
        });
      }, 30000);
      _initialized = false;
      return;
    }

    // Initialize YouTube player
    if (typeof YouTubePlayer !== 'undefined') {
      YouTubePlayer.init(container);
      observeCallState();
      console.log('[Music Bridge] YouTube player initialized');
    } else {
      console.warn('[Music Bridge] YouTubePlayer not loaded');
    }
  }

  // Start when DOM is ready
  if (document.readyState === 'complete') {
    setTimeout(init, 1000);
  } else {
    window.addEventListener('load', () => setTimeout(init, 1000));
  }

  // Listen for music access changes (e.g. user purchases addon)
  chrome.storage.onChanged.addListener(function(changes, area) {
    if (area === 'local' && changes.ailMusicAccess && changes.ailMusicAccess.newValue && !_initialized) {
      setTimeout(init, 500);
    }
  });
})();
