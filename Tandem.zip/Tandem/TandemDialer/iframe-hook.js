// iframe-hook.js — MAIN world in Plivo iframe
// Captures BOTH audio streams:
//   Remote track (client) → tandem-pcm
//   Local track (agent mic) → tandem-pcm-local
(function(){
  'use strict';
  var Orig = window.RTCPeerConnection || window.webkitRTCPeerConnection;
  if (!Orig) return;
  var capRemote = false, capLocal = false;
  var ctxR = null, procR = null, srcR = null;
  var ctxL = null, procL = null, srcL = null;

  window.RTCPeerConnection = function() {
    var pc;
    try { pc = new Orig(...arguments); } catch(e) { pc = new Orig(); }

    // ── REMOTE AUDIO (client) ──
    pc.addEventListener('track', function(e) {
      if (e.track && e.track.kind === 'audio' && !capRemote) {
        capRemote = true;
        console.log('[Tandem] Remote audio track found');
        setTimeout(function() { beginCapture(e.track, 'remote'); }, 1000);
        e.track.addEventListener('ended', function() { endCapture('remote'); });
      }
    });

    // ── LOCAL AUDIO (agent mic) — intercept addTrack ──
    var origAddTrack = pc.addTrack.bind(pc);
    pc.addTrack = function(track) {
      if (track && track.kind === 'audio' && !capLocal) {
        capLocal = true;
        console.log('[Tandem] Local audio track found (agent mic)');
        setTimeout(function() { beginCapture(track, 'local'); }, 1500);
        track.addEventListener('ended', function() { endCapture('local'); });
      }
      return origAddTrack.apply(pc, arguments);
    };

    // Legacy addStream fallback
    if (pc.addStream) {
      var origAddStream = pc.addStream.bind(pc);
      pc.addStream = function(stream) {
        if (stream && !capLocal) {
          var tracks = stream.getAudioTracks();
          if (tracks.length > 0) {
            capLocal = true;
            console.log('[Tandem] Local audio track via addStream');
            setTimeout(function() { beginCapture(tracks[0], 'local'); }, 1500);
            tracks[0].addEventListener('ended', function() { endCapture('local'); });
          }
        }
        return origAddStream.apply(pc, arguments);
      };
    }

    return pc;
  };
  window.RTCPeerConnection.prototype = Orig.prototype;
  try { Object.keys(Orig).forEach(function(k){ window.RTCPeerConnection[k] = Orig[k]; }); } catch(e){}
  if (window.webkitRTCPeerConnection) window.webkitRTCPeerConnection = window.RTCPeerConnection;

  function beginCapture(track, which) {
    try {
      if (!track || track.readyState === 'ended') { if (which === 'remote') capRemote = false; else capLocal = false; return; }
      var ctx = new AudioContext();
      ctx.resume().then(function() { wireUp(track, which, ctx); }).catch(function() { wireUp(track, which, ctx); });
    } catch(e) { if (which === 'remote') capRemote = false; else capLocal = false; }
  }

  function wireUp(track, which, ctx) {
    try {
      var stream = new MediaStream([track]);
      var sr = ctx.sampleRate || 48000, ratio = Math.max(1, Math.round(sr / 16000));
      var src = ctx.createMediaStreamSource(stream);
      var proc = ctx.createScriptProcessor(4096, 1, 1);
      var mute = ctx.createGain(); mute.gain.value = 0;
      src.connect(proc); proc.connect(mute); mute.connect(ctx.destination);
      var msgType = which === 'local' ? 'tandem-pcm-local' : 'tandem-pcm';
      proc.onaudioprocess = function(ev) {
        try {
          var ch = ev.inputBuffer.getChannelData(0);
          var s = 0; for (var i = 0; i < ch.length; i += 8) s += Math.abs(ch[i]);
          if (s / (ch.length / 8) < 0.001) return;
          var len = Math.floor(ch.length / ratio), out = new Int16Array(len);
          for (var i = 0; i < len; i++) { var v = Math.max(-1, Math.min(1, ch[i * ratio])); out[i] = v < 0 ? v * 0x8000 : v * 0x7FFF; }
          window.postMessage({ type: msgType, buffer: out.buffer }, '*');
        } catch(e) {}
      };
      if (which === 'remote') { ctxR = ctx; procR = proc; srcR = src; }
      else { ctxL = ctx; procL = proc; srcL = src; }
      window.postMessage({ type: which === 'remote' ? 'tandem-capture-started' : 'tandem-local-capture-started' }, '*');
      console.log('[Tandem] Capture running (' + which + ' sr=' + sr + ')');
    } catch(e) { if (which === 'remote') capRemote = false; else capLocal = false; }
  }

  function endCapture(which) {
    if (which === 'remote') {
      capRemote = false;
      try { if (procR) { procR.onaudioprocess = null; procR.disconnect(); } } catch(e){}
      try { if (srcR) srcR.disconnect(); } catch(e){}
      try { if (ctxR && ctxR.state !== 'closed') ctxR.close(); } catch(e){}
      procR = null; srcR = null; ctxR = null;
      window.postMessage({ type: 'tandem-capture-stopped' }, '*');
    } else {
      capLocal = false;
      try { if (procL) { procL.onaudioprocess = null; procL.disconnect(); } } catch(e){}
      try { if (srcL) srcL.disconnect(); } catch(e){}
      try { if (ctxL && ctxL.state !== 'closed') ctxL.close(); } catch(e){}
      procL = null; srcL = null; ctxL = null;
      window.postMessage({ type: 'tandem-local-capture-stopped' }, '*');
    }
  }
})();
