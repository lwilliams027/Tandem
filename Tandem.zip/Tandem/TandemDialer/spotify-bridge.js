// ═══════════════════════════════════════════════════════
// spotify-bridge.js — Observes call state, injects Spotify minibar
// Loaded as a separate content script alongside content.js
// Zero changes needed to the minified content.js
// ═══════════════════════════════════════════════════════

(function() {
  'use strict';

  const SERVER = 'https://ail-autodialer-server.onrender.com';
  let _initialized = false;
  let _lastState = '';
  let _wasOnCall = false;

  // ─── Wait for overlay panel to exist ───
  function waitForPanel() {
    return new Promise(resolve => {
      const check = () => {
        const panel = document.getElementById('ail-dialer-panel');
        if (panel) return resolve(panel);
        setTimeout(check, 500);
      };
      check();
    });
  }

  // ─── Get auth token ───
  async function getToken() {
    return new Promise(resolve => {
      try {
        chrome.storage.local.get(['sbToken'], r => {
          resolve(r.sbToken || null);
        });
      } catch(e) {
        resolve(null);
      }
    });
  }

  // ─── Inject Spotify bar container into overlay ───
  function injectContainer(panel) {
    // Check if already injected
    if (document.getElementById('ail-spotify-bar')) return;

    const container = document.createElement('div');
    container.id = 'ail-spotify-bar';

    // Insert into the phone-bottom area, before the stats
    const phoneBottom = panel.querySelector('.ail-phone-bottom');
    const stats = panel.querySelector('.ail-stats');
    if (phoneBottom && stats) {
      phoneBottom.insertBefore(container, stats);
    } else {
      // Fallback: append to phone body
      const body = panel.querySelector('.ail-phone-body');
      if (body) body.appendChild(container);
    }

    return container;
  }

  // ─── Detect call state from overlay DOM ───
  function getCurrentState() {
    const statusEl = document.getElementById('ail-status');
    if (!statusEl) return 'unknown';
    const text = statusEl.textContent.toLowerCase().trim();
    if (text.includes('connected')) return 'connected';
    if (text.includes('ringing')) return 'ringing';
    if (text.includes('dialing')) return 'dialing';
    if (text.includes('call ended')) return 'ended';
    if (text.includes('ready')) return 'ready';
    if (text.includes('stopped')) return 'stopped';
    return 'other';
  }

  // ─── Observe state changes ───
  function observeCallState() {
    const statusEl = document.getElementById('ail-status');
    if (!statusEl) return;

    // Use MutationObserver on the status text
    const observer = new MutationObserver(() => {
      const newState = getCurrentState();
      if (newState === _lastState) return;
      
      const prevState = _lastState;
      _lastState = newState;

      // CONNECTED → pause Spotify
      if (newState === 'connected' && !_wasOnCall) {
        _wasOnCall = true;
        console.log('[Spotify Bridge] Call connected — pausing music');
        if (typeof SpotifyMinibar !== 'undefined') {
          SpotifyMinibar.onCallAnswered();
        }
      }

      // Call ended (was on call) → resume Spotify
      if (_wasOnCall && (newState === 'ready' || newState === 'stopped' || newState === 'ended' || newState === 'other')) {
        // Small delay — make sure the call is truly over (not just a status flicker)
        setTimeout(() => {
          const confirmState = getCurrentState();
          if (confirmState !== 'connected' && confirmState !== 'ringing' && confirmState !== 'dialing') {
            _wasOnCall = false;
            console.log('[Spotify Bridge] Call ended — resuming music');
            if (typeof SpotifyMinibar !== 'undefined') {
              SpotifyMinibar.onCallEnded();
            }
          }
        }, 500);
      }
    });

    observer.observe(statusEl, { childList: true, characterData: true, subtree: true });

    // Also listen for window messages (more reliable for some events)
    window.addEventListener('message', e => {
      if (!e.data || !e.data.type) return;
      
      if (e.data.type === 'ail-terminated' && _wasOnCall) {
        setTimeout(() => {
          _wasOnCall = false;
          console.log('[Spotify Bridge] Call terminated (message) — resuming music');
          if (typeof SpotifyMinibar !== 'undefined') {
            SpotifyMinibar.onCallEnded();
          }
        }, 500);
      }
    });
  }

  // ─── Main ───
  async function init() {
    if (_initialized) return;
    _initialized = true;

    // Wait for the overlay panel to be created by content.js
    const panel = await waitForPanel();
    console.log('[Spotify Bridge] Panel found, injecting Spotify bar');

    // Inject the container
    const container = injectContainer(panel);
    if (!container) {
      console.warn('[Spotify Bridge] Could not inject container');
      return;
    }

    // Get auth token
    const token = await getToken();
    if (!token) {
      console.log('[Spotify Bridge] No auth token — Spotify bar hidden until login');
      // Re-check after a delay (user might log in)
      setTimeout(async () => {
        const t = await getToken();
        if (t && typeof SpotifyMinibar !== 'undefined') {
          SpotifyMinibar.init(container, SERVER, t);
          observeCallState();
        }
      }, 10000);
      return;
    }

    // Initialize the minibar
    if (typeof SpotifyMinibar !== 'undefined') {
      SpotifyMinibar.init(container, SERVER, token);
      observeCallState();
      console.log('[Spotify Bridge] Initialized');
    } else {
      console.warn('[Spotify Bridge] SpotifyMinibar not loaded');
    }

    // Re-init if token changes (login/logout)
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes.sbToken) {
        const newToken = changes.sbToken.newValue;
        if (newToken && typeof SpotifyMinibar !== 'undefined') {
          SpotifyMinibar.init(container, SERVER, newToken);
          if (!_lastState) observeCallState();
        }
      }
    });
  }

  // Start when DOM is ready
  if (document.readyState === 'complete') {
    setTimeout(init, 1000); // Give content.js time to build overlay
  } else {
    window.addEventListener('load', () => setTimeout(init, 1000));
  }
})();
